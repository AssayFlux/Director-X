# Director X — Mobile Design System

**Brand line:** Designed by AssayFlux

## Design principles
- Vintage / skeuomorphic analog aesthetic: new retro, editorial, darkroom, photo-paper references.
- Elegant serif display headings; clean sans-serif labels, controls, metadata, and dense editing values.
- Warm paper canvas and tactile beige surfaces; fine taupe borders rather than heavy shadows.
- Minimal line-art symbols, with restrained stars, sunbursts, aperture and film motifs.
- Touch controls retain generous minimum targets and readable labels.
- The preview footage must remain visually dominant; chrome is intentionally calm.

## Brand tokens
| Token | Hex | Use |
|---|---|---|
| Canvas / aged paper | `#F5F0E6` | Main app background, status/navigation fallback |
| Surface / warm beige | `#EAE3D2` | Cards, sheets, secondary panels |
| Primary text | `#2C2621` | Headlines, body text, primary button labels on amber |
| Secondary / border | `#8C8275` | Muted labels, outlines, separators |
| Vintage amber | `#C29B38` | Primary action, selection, highlights |
| Muted sage | `#5A6B57` | Success, secondary action, active/confirmed states |

## Typography
- Display and major headings: platform serif family, medium/semibold.
- Body and interface: platform sans-serif, regular/medium.
- Metadata: compact sans-serif, muted taupe, never below accessible legibility.

## Components
- Cards and sheets use warm beige surfaces and 8–12 dp corners.
- Primary buttons use amber with charcoal labels; when pressed into sage, use cream labels.
- Secondary controls use beige surfaces, taupe outlines, and charcoal text.
- Selected states use a low-opacity amber wash and a clear border/icon cue.
- Success is sage; warning is amber; errors use a restrained brick-red rather than neon.
- Focus indicators remain strong enough to be distinguishable against both cream and beige.

## Engineering notes
- Central palette is in `app/src/main/java/com/novacut/editor/ui/theme/Theme.kt`.
- Android fallback colors are in `app/src/main/res/values/colors.xml` and `themes.xml`.
- Existing internal class/package names remain unchanged in this pass to avoid a risky package migration.
- Visual captures were removed; regenerate them from the running app with the visual-capture test property after the new UI is built.
