# Director X source inventory and verification

- Files in modified source tree: 841
- Production Kotlin files: 363 (127,528 lines)
- Unit-test Kotlin files: 297
- XML resources/manifests parsed successfully: 19
- PNG/SVG artwork retained: 25; old promo/dev/test screenshot folders removed.
- Native FFmpegKitNext AAR SHA-256: `7971240aff84ce59a4ab28400bb4af59d24c20ce68c25525d41d910246ccff62` (matches Gradle pin)
- Store listing asset generator and validator passed.
- Python release/listing scripts compile successfully.
- Android Gradle tests/build could not be run here: Gradle wrapper attempted to fetch Gradle 9.8, but network DNS is unavailable.

## Files retained intentionally
- `LICENSE`, `NOTICE`, `third_party/`, native lock files, corresponding-source recipe, and bundled licence resources.
- Production source, tests, test media fixtures, database schemas, Gradle build logic, and scripts.
- Existing package namespace and internal serialization/file extensions remain stable in this pass.

## Remaining before public release
- Configure a Director X public repository and update both locale privacy-policy URLs.
- Set the Director X release-signing identity and repository for release-sidecar verification.
- Run Android unit tests, lint, debug/release builds, and device tests.
- Capture real phone/tablet screenshots from a verified build before restoring store screenshots.
