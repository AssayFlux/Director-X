# Director X source rebrand report

## Applied in this pass
- App display name changed to **Director X**; added brand credit resource **Designed by AssayFlux**.
- Android fallback surfaces changed to the warm-cream palette.
- Compose palette changed to cream, beige, charcoal, taupe, amber, and sage values.
- Display/headline typography changed to serif; body/control typography remains sans-serif.
- Launcher icon art replaced with an original vintage film-camera/aperture mark.
- README rewritten for Director X and documents upstream derivation transparently.
- Removed old product promotional/dev artwork and screenshots from `artifacts/`, `work/`, Play listing image directories, and old logo SVG.
- Removed old screenshot captures, including old visual test captures. Visual verification tests now create fresh cream-theme captures on demand.
- Preserved MIT `LICENSE`, third-party `NOTICE`, native source-offer materials, schemas, tests, and executable source.
- Kept package/application identifiers and internal serialization formats stable to reduce risk of breaking existing data and integrations.

## Verification still required
- Gradle tests/build could not run in this container because the wrapper needs to download Gradle 9.8 and network access is unavailable. Run unit tests, lint, and debug/release builds in an Android SDK-enabled environment.
- Capture new phone/tablet screenshots from a verified Director X build before publishing a store listing.
- Audit remaining user-visible hard-coded text and test screenshot baselines as UI redesign progresses.
- The `brand_credit` resource is shown in the About section of Settings.
- The English and Spanish Play privacy-policy URLs still point to the upstream repository because no Director X public repository/domain was supplied; update them before publishing. The inherited policy contact was removed rather than presenting the upstream maintainer as the Director X contact.
- Automatic release checking is disabled until a Director X release repository is configured; the release-sidecar script now requires `DIRECTOR_X_GITHUB_REPO` rather than hardcoding the upstream repository.
