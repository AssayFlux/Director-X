package com.novacut.editor.ui.editor

import android.net.FakeUri
import androidx.media3.common.Player
import com.novacut.editor.engine.playbackSessionNeedsReset
import com.novacut.editor.model.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class TimelineEditingTest {

    @Test
    fun `trim preview refreshes only when retained media extends beyond prepared range`() {
        val prepared = PreparedTrimRange(startMs = 200L, endMs = 800L)

        assertFalse(
            trimExtendsPreparedRange(
                prepared,
                clip("same", 0L, 200L, 800L, 1_000L)
            )
        )
        assertFalse(
            trimExtendsPreparedRange(
                prepared,
                clip("inward", 0L, 300L, 700L, 1_000L)
            )
        )
        assertTrue(
            trimExtendsPreparedRange(
                prepared,
                clip("earlier", 0L, 100L, 800L, 1_000L)
            )
        )
        assertTrue(
            trimExtendsPreparedRange(
                prepared,
                clip("later", 0L, 200L, 900L, 1_000L)
            )
        )
        // The gesture-start range stays immutable, so a retract followed by a
        // smaller re-extension remains eligible even if an earlier refresh ran.
        assertTrue(
            trimExtendsPreparedRange(
                prepared,
                clip("re-extended", 0L, 150L, 800L, 1_000L)
            )
        )
    }

    @Test
    fun `slip planner distinguishes clamped no-op from effective delta`() {
        val atSourceStart = clip(
            id = "clip",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 1_000L,
        )
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(atSourceStart)))

        assertEquals(
            tracks,
            slipLinkedClipsOnTimeline(tracks, setOf(atSourceStart.id), slipAmountMs = -100L),
        )
        val shifted = slipLinkedClipsOnTimeline(
            tracks,
            setOf(atSourceStart.id),
            slipAmountMs = 100L,
        )
        assertEquals(100L, shifted.single().clips.single().trimStartMs)
        assertEquals(600L, shifted.single().clips.single().trimEndMs)
    }

    @Test
    fun `ntsc slip shifts source boundaries by frames rather than rounded milliseconds`() {
        val source = clip("source", 0L, 33L, 100L, 1_000L)
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(source)))

        val shifted = slipLinkedClipsOnTimeline(
            tracks,
            setOf(source.id),
            slipAmountMs = 33L,
            timebase = TimelineTimebase.NTSC_29_97,
        ).single().clips.single()

        assertEquals(67L, shifted.trimStartMs)
        assertEquals(133L, shifted.trimEndMs)
    }

    @Test
    fun `playback session resets for ended idle failed and watchdog recovery states`() {
        assertTrue(playbackSessionNeedsReset(false, Player.STATE_ENDED, false))
        assertTrue(playbackSessionNeedsReset(false, Player.STATE_IDLE, false))
        assertTrue(playbackSessionNeedsReset(false, Player.STATE_READY, true))
        assertTrue(playbackSessionNeedsReset(true, Player.STATE_BUFFERING, false))
        assertTrue(playbackSessionNeedsReset(false, Player.STATE_BUFFERING, false, playbackRequested = false))
        assertFalse(playbackSessionNeedsReset(false, Player.STATE_READY, false))
        assertFalse(playbackSessionNeedsReset(false, Player.STATE_BUFFERING, false))
    }

    @Test
    fun `playback restarts from zero after reaching the edited timeline end`() {
        assertEquals(0L, playbackStartPosition(playheadMs = 4_000L, totalDurationMs = 4_000L))
        assertEquals(0L, playbackStartPosition(playheadMs = 5_000L, totalDurationMs = 4_000L))
        assertEquals(2_500L, playbackStartPosition(playheadMs = 2_500L, totalDurationMs = 4_000L))
        assertEquals(0L, playbackStartPosition(playheadMs = 0L, totalDurationMs = 0L))
    }

    @Test
    fun `cut toolbar follows the live playhead when no clip is selected`() {
        val first = clip("first", 0L, 0L, 1_000L, 1_000L)
        val second = clip("second", 1_000L, 0L, 1_000L, 1_000L)
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(first, second)))

        assertTrue(canSplitTimelineAtPlayhead(tracks, selectedClipId = null, playheadMs = 500L))
        assertFalse(canSplitTimelineAtPlayhead(tracks, selectedClipId = null, playheadMs = 0L))
        assertFalse(canSplitTimelineAtPlayhead(tracks, selectedClipId = first.id, playheadMs = 1_500L))
        assertTrue(canSplitTimelineAtPlayhead(tracks, selectedClipId = second.id, playheadMs = 1_500L))
    }

    @Test
    fun `long press opens compound clips through ViewModel callback`() {
        var openedClipId: String? = null
        var toggledClipId: String? = null

        val result = dispatchTimelineClipLongPress(
            clipId = "compound",
            isCompound = true,
            onOpenCompoundClip = { clipId ->
                openedClipId = clipId
                true
            },
            onToggleMultiSelect = { clipId -> toggledClipId = clipId }
        )

        assertEquals(TimelineClipLongPressResult.OPENED_COMPOUND, result)
        assertEquals("compound", openedClipId)
        assertNull(toggledClipId)
    }

    @Test
    fun `long press keeps multi-select fallback for regular clips and rejected compound opens`() {
        var regularToggledClipId: String? = null
        val regularResult = dispatchTimelineClipLongPress(
            clipId = "regular",
            isCompound = false,
            onOpenCompoundClip = { true },
            onToggleMultiSelect = { clipId -> regularToggledClipId = clipId }
        )

        var rejectedToggledClipId: String? = null
        val rejectedResult = dispatchTimelineClipLongPress(
            clipId = "compound",
            isCompound = true,
            onOpenCompoundClip = { false },
            onToggleMultiSelect = { clipId -> rejectedToggledClipId = clipId }
        )

        assertEquals(TimelineClipLongPressResult.TOGGLED_MULTI_SELECT, regularResult)
        assertEquals("regular", regularToggledClipId)
        assertEquals(TimelineClipLongPressResult.TOGGLED_MULTI_SELECT, rejectedResult)
        assertEquals("compound", rejectedToggledClipId)
    }

    @Test
    fun `snap target returns nearest position within threshold`() {
        val targets = listOf(0L, 1_000L, 1_900L, 4_000L)

        assertEquals(1_900L, findSnapTarget(positionMs = 2_020L, targets = targets, thresholdMs = 150L))
        assertNull(findSnapTarget(positionMs = 2_020L, targets = targets, thresholdMs = 100L))
    }

    @Test
    fun `timeline position hit test includes clip start and excludes clip end`() {
        val clip = clip(
            id = "clip",
            timelineStartMs = 1_000L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 500L
        )

        assertFalse(clip.containsTimelinePosition(999L))
        assertTrue(clip.containsTimelinePosition(1_000L))
        assertTrue(clip.containsTimelinePosition(1_499L))
        assertFalse(clip.containsTimelinePosition(1_500L))
    }

    @Test
    fun `accessible split point uses playhead inside safe range and midpoint otherwise`() {
        val clip = clip(
            id = "clip",
            timelineStartMs = 1_000L,
            trimStartMs = 0L,
            trimEndMs = 1_000L,
            sourceDurationMs = 1_000L
        )

        assertEquals(1_250L, clip.accessibleSplitPointMs(1_250L))
        assertEquals(1_500L, clip.accessibleSplitPointMs(5_000L))
    }

    @Test
    fun `accessible split point is unavailable for sub minimum clips`() {
        val clip = clip(
            id = "short",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 150L,
            sourceDurationMs = 150L
        )

        assertNull(clip.accessibleSplitPointMs(50L))
    }

    @Test
    fun `keyboard nudge switches to coarse steps when shift is held`() {
        assertEquals(100L, keyboardNudgeAmountMs(isShiftPressed = false))
        assertEquals(1_000L, keyboardNudgeAmountMs(isShiftPressed = true))
    }

    @Test
    fun `overview tap centers viewport on tapped timeline fraction`() {
        assertEquals(
            4_000L,
            timelineOverviewScrollOffsetForTap(
                xPx = 50f,
                widthPx = 100f,
                totalDurationMs = 10_000L,
                visibleDurationMs = 2_000L,
                currentScrollOffsetMs = 250L
            )
        )
        assertEquals(
            250L,
            timelineOverviewScrollOffsetForTap(
                xPx = 50f,
                widthPx = 0f,
                totalDurationMs = 10_000L,
                visibleDurationMs = 2_000L,
                currentScrollOffsetMs = 250L
            )
        )
    }

    @Test
    fun `timeline clip names clean file-like source labels and keep fallbacks for generated names`() {
        assertEquals("Vacation opening take", formatTimelineClipName("Vacation_opening%20take.mov", fallback = "Video"))
        assertEquals("Video", formatTimelineClipName("IMG_20240604_120000.mp4", fallback = "Video"))
        assertEquals("Video", formatTimelineClipName("20240604120000.mp4", fallback = "Video"))
        assertEquals("Video", formatTimelineClipName(null, fallback = "Video"))
    }

    @Test
    fun `timeline formatters keep compact editor labels stable`() {
        assertEquals("0:00", formatTimelineTime(-1_000L))
        assertEquals("1:01", formatTimelineTime(61_000L))
        assertEquals("1:01:01", formatTimelineTime(3_661_000L))
        assertEquals("0.5s", formatTimelineDurationLabel(500L))
        assertEquals("1:01", formatTimelineDurationLabel(61_000L))
        assertEquals("2x", formatSpeedLabel(2.04f))
        assertEquals("1.3x", formatSpeedLabel(1.25f))
    }

    @Test
    fun `volume keyframes are filtered and sorted for envelope rendering`() {
        val sourceClip = clip(
            id = "audio",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 1_000L,
            sourceDurationMs = 1_000L
        ).copy(
            keyframes = listOf(
                Keyframe(timeOffsetMs = 300L, property = KeyframeProperty.VOLUME, value = 0.9f),
                Keyframe(timeOffsetMs = 10L, property = KeyframeProperty.OPACITY, value = 0.5f),
                Keyframe(timeOffsetMs = 100L, property = KeyframeProperty.VOLUME, value = 0.4f)
            )
        )

        assertEquals(listOf(100L, 300L), volumeKeyframesSorted(sourceClip).map { it.timeOffsetMs })
    }

    @Test
    fun `leading trim moves the clip start on the timeline`() {
        val clip = clip(
            id = "clip",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 1_000L,
            sourceDurationMs = 1_000L
        )
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(clip))

        val trimmedTrack = trimClipOnTrack(
            track = track,
            clipId = clip.id,
            requestedTrimStartMs = 200L
        )
        val trimmedClip = trimmedTrack.clips.single()

        assertEquals(200L, trimmedClip.timelineStartMs)
        assertEquals(200L, trimmedClip.trimStartMs)
        assertEquals(1_000L, trimmedClip.timelineEndMs)
    }

    @Test
    fun `sequential trims compose against the already trimmed source window`() {
        val original = clip(
            id = "clip",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 1_000L,
            sourceDurationMs = 1_000L,
        )
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(original))

        val afterLeadingTrim = trimClipOnTrack(
            track = track,
            clipId = original.id,
            requestedTrimStartMs = 200L,
        )
        val afterTrailingTrim = trimClipOnTrack(
            track = afterLeadingTrim,
            clipId = original.id,
            requestedTrimEndMs = 600L,
        ).clips.single()

        assertEquals(200L, afterTrailingTrim.trimStartMs)
        assertEquals(600L, afterTrailingTrim.trimEndMs)
        assertEquals(200L, afterTrailingTrim.timelineStartMs)
        assertEquals(600L, afterTrailingTrim.timelineEndMs)
    }

    @Test
    fun `a second leading trim is absolute within the current source window`() {
        val original = clip("clip", 0L, 0L, 1_000L, 1_000L)
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(original))

        val first = trimClipOnTrack(track, original.id, requestedTrimStartMs = 200L)
        val second = trimClipOnTrack(first, original.id, requestedTrimStartMs = 300L).clips.single()

        assertEquals(300L, second.trimStartMs)
        assertEquals(300L, second.timelineStartMs)
        assertEquals(1_000L, second.timelineEndMs)
    }

    @Test
    fun `leading trim respects the previous clip boundary`() {
        val previous = clip(
            id = "prev",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 400L,
            sourceDurationMs = 400L
        )
        val target = clip(
            id = "target",
            timelineStartMs = 400L,
            trimStartMs = 200L,
            trimEndMs = 800L,
            sourceDurationMs = 1_000L
        )
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(previous, target))

        val trimmedTrack = trimClipOnTrack(
            track = track,
            clipId = target.id,
            requestedTrimStartMs = 0L
        )
        val trimmedClip = trimmedTrack.clips.last()

        assertEquals(400L, trimmedClip.timelineStartMs)
        assertEquals(200L, trimmedClip.trimStartMs)
        assertEquals(1_000L, trimmedClip.timelineEndMs)
    }

    @Test
    fun `linked leading trim uses the most restrictive neighboring boundary`() {
        val video = clip("video", 500L, 200L, 1_000L, 1_000L)
        val audio = clip("audio", 500L, 200L, 1_000L, 1_000L)
        val videoTrack = Track(
            type = TrackType.VIDEO,
            index = 0,
            clips = listOf(clip("video-prev", 0L, 0L, 400L, 400L), video)
        )
        val audioTrack = Track(
            type = TrackType.AUDIO,
            index = 1,
            clips = listOf(clip("audio-prev", 0L, 0L, 450L, 450L), audio)
        )

        val trimmedTracks = trimLinkedClipsOnTimeline(
            tracks = listOf(videoTrack, audioTrack),
            anchorClipId = video.id,
            targetClipIds = setOf(video.id, audio.id),
            requestedTrimStartMs = 0L
        )

        val trimmedVideo = trimmedTracks[0].clips.last()
        val trimmedAudio = trimmedTracks[1].clips.last()
        assertEquals(450L, trimmedVideo.timelineStartMs)
        assertEquals(450L, trimmedAudio.timelineStartMs)
        assertEquals(150L, trimmedVideo.trimStartMs)
        assertEquals(150L, trimmedAudio.trimStartMs)
        assertEquals(trimmedVideo.timelineEndMs, trimmedAudio.timelineEndMs)
    }

    @Test
    fun `linked trailing trim uses the most restrictive next clip boundary`() {
        val video = clip("video", 0L, 0L, 600L, 1_000L)
        val audio = clip("audio", 0L, 0L, 600L, 1_000L)
        val videoTrack = Track(
            type = TrackType.VIDEO,
            index = 0,
            clips = listOf(video, clip("video-next", 900L, 0L, 100L, 100L))
        )
        val audioTrack = Track(
            type = TrackType.AUDIO,
            index = 1,
            clips = listOf(audio, clip("audio-next", 700L, 0L, 100L, 100L))
        )

        val trimmedTracks = trimLinkedClipsOnTimeline(
            tracks = listOf(videoTrack, audioTrack),
            anchorClipId = video.id,
            targetClipIds = setOf(video.id, audio.id),
            requestedTrimEndMs = 1_000L
        )

        val trimmedVideo = trimmedTracks[0].clips.first()
        val trimmedAudio = trimmedTracks[1].clips.first()
        assertEquals(700L, trimmedVideo.timelineEndMs)
        assertEquals(700L, trimmedAudio.timelineEndMs)
        assertEquals(700L, trimmedVideo.trimEndMs)
        assertEquals(700L, trimmedAudio.trimEndMs)
    }

    @Test
    fun `slide edit keeps neighboring clips connected`() {
        val first = clip(
            id = "a",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 800L
        )
        val middle = clip(
            id = "b",
            timelineStartMs = 500L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 500L
        )
        val last = clip(
            id = "c",
            timelineStartMs = 1_000L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 800L
        )
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(first, middle, last))

        val shiftedTrack = slideClipOnTrack(
            track = track,
            clipId = middle.id,
            newStartMs = 600L
        )

        assertEquals(600L, shiftedTrack.clips[1].timelineStartMs)
        assertEquals(600L, shiftedTrack.clips[0].timelineEndMs)
        assertEquals(1_100L, shiftedTrack.clips[2].timelineStartMs)
        assertEquals(100L, shiftedTrack.clips[2].trimStartMs)
    }

    @Test
    fun `slide edit honors speed curve timing when extending previous clip`() {
        val first = clip(
            id = "a",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 1_000L,
            sourceDurationMs = 2_000L,
            speedCurve = SpeedCurve.constant(2f)
        )
        val second = clip(
            id = "b",
            timelineStartMs = first.timelineEndMs,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 500L
        )
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(first, second))

        val shiftedTrack = slideClipOnTrack(
            track = track,
            clipId = second.id,
            newStartMs = 600L
        )

        assertWithin(1_200L, shiftedTrack.clips[0].trimEndMs, toleranceMs = 4L)
        assertEquals(600L, shiftedTrack.clips[1].timelineStartMs)
    }

    @Test
    fun `preferred audio track skips overlapping lanes`() {
        val overlappingAudio = Track(
            type = TrackType.AUDIO,
            index = 0,
            clips = listOf(
                clip(
                    id = "busy",
                    timelineStartMs = 0L,
                    trimStartMs = 0L,
                    trimEndMs = 1_000L,
                    sourceDurationMs = 1_000L
                )
            )
        )
        val openAudio = Track(type = TrackType.AUDIO, index = 1)

        val audioTrackIndex = preferredAudioTrackIndex(
            tracks = listOf(overlappingAudio, openAudio),
            startMs = 200L,
            endMs = 800L
        )

        assertEquals(1, audioTrackIndex)
    }

    @Test
    fun `preferred audio track returns null when all tracks overlap`() {
        val busyAudio = Track(
            type = TrackType.AUDIO,
            index = 0,
            clips = listOf(
                clip(
                    id = "busy",
                    timelineStartMs = 0L,
                    trimStartMs = 0L,
                    trimEndMs = 1_000L,
                    sourceDurationMs = 1_000L
                )
            )
        )

        val audioTrackIndex = preferredAudioTrackIndex(
            tracks = listOf(busyAudio),
            startMs = 200L,
            endMs = 800L
        )

        assertNull(audioTrackIndex)
    }

    @Test
    fun `merge predicate accepts clips that touch in source and timeline`() {
        val first = clip(
            id = "first",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 1_000L
        )
        val second = clip(
            id = "second",
            timelineStartMs = 500L,
            trimStartMs = 500L,
            trimEndMs = 1_000L,
            sourceDurationMs = 1_000L
        )

        assertTrue(canMergeAdjacentClips(first, second))
    }

    @Test
    fun `merge predicate rejects clips separated by a timeline gap`() {
        val first = clip(
            id = "first",
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 500L,
            sourceDurationMs = 1_000L
        )
        val second = clip(
            id = "second",
            timelineStartMs = 700L,
            trimStartMs = 500L,
            trimEndMs = 1_000L,
            sourceDurationMs = 1_000L
        )

        assertFalse(canMergeAdjacentClips(first, second))
    }

    @Test
    fun `merge predicate rejects retiming, reverse, volume, or speed-curve mismatches`() {
        val first = clip("first", 0L, 0L, 500L, 1_000L)
        val second = clip("second", 500L, 500L, 1_000L, 1_000L)
        // Baseline: identical retiming merges.
        assertTrue(canMergeAdjacentClips(first, second))
        // Merging collapses into the first clip's timing model, so any of these
        // differences would corrupt duration/playback and must block the merge.
        assertFalse("speed mismatch", canMergeAdjacentClips(first, second.copy(speed = 2f)))
        assertFalse("reverse mismatch", canMergeAdjacentClips(first, second.copy(isReversed = true)))
        assertFalse("volume mismatch", canMergeAdjacentClips(first, second.copy(volume = 0.5f)))
        assertFalse("first has speed curve", canMergeAdjacentClips(first.copy(speedCurve = SpeedCurve()), second))
        assertFalse("second has speed curve", canMergeAdjacentClips(first, second.copy(speedCurve = SpeedCurve())))
    }

    @Test
    fun `merging adjacent clips preserves every following timeline position`() {
        val first = clip("first", 0L, 0L, 4_000L, 10_000L)
        val second = clip("second", 4_000L, 4_000L, 10_000L, 10_000L)
        val following = clip("following", 10_000L, 10_000L, 24_000L, 34_000L)
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(first, second, following))

        val merged = mergeAdjacentClipPair(track, first.id)

        assertEquals(listOf("first", "following"), merged.clips.map { it.id })
        assertEquals(10_000L, merged.clips.first().durationMs)
        assertEquals(10_000L, merged.clips.last().timelineStartMs)
    }

    @Test
    fun `reorder preserves intentional gaps and the track span`() {
        // Layout: [a 0..1000] gap(500) [b 1500..3500] gap(1000) [c 4500..5000]
        val a = clip("a", timelineStartMs = 0L, trimStartMs = 0L, trimEndMs = 1_000L, sourceDurationMs = 10_000L)
        val b = clip("b", timelineStartMs = 1_500L, trimStartMs = 0L, trimEndMs = 2_000L, sourceDurationMs = 10_000L)
        val c = clip("c", timelineStartMs = 4_500L, trimStartMs = 0L, trimEndMs = 500L, sourceDurationMs = 10_000L)

        // Move c to the front.
        val reordered = reorderClipsPreservingGaps(listOf(a, b, c), "c", targetIndex = 0)

        assertEquals(listOf("c", "a", "b"), reordered.map { it.id })
        // Leading offset preserved; gaps travel with position (500 then 1000).
        assertEquals(0L, reordered[0].timelineStartMs)      // c: 0..500
        assertEquals(1_000L, reordered[1].timelineStartMs)  // a after 500 gap: 1000..2000
        assertEquals(3_000L, reordered[2].timelineStartMs)  // b after 1000 gap: 3000..5000
        // Track span preserved (still ends at 5000) and no overlaps.
        assertEquals(5_000L, reordered.last().timelineEndMs)
        for (i in 0 until reordered.lastIndex) {
            assertTrue(reordered[i].timelineEndMs <= reordered[i + 1].timelineStartMs)
        }
    }

    @Test
    fun `reorder leaves clips untouched when the id is absent`() {
        val a = clip("a", 0L, 0L, 1_000L, 10_000L)
        val original = listOf(a)
        assertEquals(original, reorderClipsPreservingGaps(original, "missing", 0))
    }

    @Test
    fun `duplicate ripple offset is the max duration across the linked closure`() {
        // A linked video/audio pair with different durations on two tracks.
        val video = clip("v", 0L, 0L, 3_000L, 10_000L)   // 3000ms
        val audio = clip("a", 0L, 0L, 2_000L, 10_000L)   // 2000ms
        val tracks = listOf(
            Track(type = TrackType.VIDEO, index = 0, clips = listOf(video)),
            Track(type = TrackType.AUDIO, index = 1, clips = listOf(audio)),
        )
        // A single uniform offset (the max) keeps both tracks shifted equally.
        assertEquals(3_000L, linkedClosureRippleOffset(tracks, setOf("v", "a")))
    }

    @Test
    fun `duplicate ripple offset for a single clip equals its own duration`() {
        val only = clip("only", 0L, 0L, 1_500L, 10_000L)
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(only)))
        assertEquals(1_500L, linkedClosureRippleOffset(tracks, setOf("only")))
    }

    @Test
    fun `slip on a short source keeps trimEnd within the source (no Clip init crash)`() {
        // 80ms source with a 60ms window: the old coerceAtLeast(100) pushed the
        // window past the source and crashed Clip.init's require(trimEnd <= source).
        val short = clip("short", timelineStartMs = 0L, trimStartMs = 0L, trimEndMs = 60L, sourceDurationMs = 80L)
        val track = Track(type = TrackType.VIDEO, index = 0, clips = listOf(short))

        // timebase == null exercises the branch that previously crashed.
        val result = slipLinkedClipsOnTimeline(listOf(track), setOf("short"), slipAmountMs = 30L, timebase = null)

        val slipped = result.first().clips.first()
        assertTrue("trimEnd must stay within the source", slipped.trimEndMs <= slipped.sourceDurationMs)
        assertTrue("trimStart must be non-negative", slipped.trimStartMs >= 0L)
        // The window duration is preserved (slip shifts, doesn't resize).
        assertEquals(60L, slipped.trimEndMs - slipped.trimStartMs)
    }

    @Test
    fun `edit target expansion includes linked clips and every member of selected groups`() {
        val groupedVideo = clip("video", 0L, 0L, 500L, 500L).copy(
            linkedClipId = "audio",
            groupId = "scene"
        )
        val linkedAudio = clip("audio", 0L, 0L, 500L, 500L).copy(linkedClipId = "video")
        val groupedOverlay = clip("overlay", 700L, 0L, 300L, 300L).copy(groupId = "scene")
        val tracks = listOf(
            Track(type = TrackType.VIDEO, index = 0, clips = listOf(groupedVideo)),
            Track(type = TrackType.AUDIO, index = 1, clips = listOf(linkedAudio)),
            Track(type = TrackType.OVERLAY, index = 2, clips = listOf(groupedOverlay))
        )

        assertEquals(
            setOf("video", "audio", "overlay"),
            expandTimelineEditClipIds(tracks, setOf("video"))
        )
    }

    @Test
    fun `linked split rejects the entire pair when one member is too short`() {
        val video = clip("video", 0L, 0L, 1_000L, 1_000L).copy(linkedClipId = "audio")
        val audio = clip("audio", 0L, 0L, 550L, 550L).copy(linkedClipId = "video")
        val tracks = listOf(
            Track(type = TrackType.VIDEO, index = 0, clips = listOf(video)),
            Track(type = TrackType.AUDIO, index = 1, clips = listOf(audio))
        )

        assertTrue(linkedSplitCandidateIds(tracks, setOf(video.id), 500L).isEmpty())
        assertEquals(
            setOf("video", "audio"),
            linkedSplitCandidateIds(tracks, setOf(video.id), 300L)
        )
    }

    @Test
    fun `source beat markers map through trim speed and timeline start`() {
        val retimed = clip(
            id = "audio",
            timelineStartMs = 5_000L,
            trimStartMs = 1_000L,
            trimEndMs = 3_000L,
            sourceDurationMs = 4_000L
        ).copy(speed = 2f)

        assertEquals(
            listOf(5_250L, 5_750L),
            mapSourceMarkersToTimeline(retimed, listOf(500L, 1_500L, 2_500L, 3_500L))
        )
    }

    @Test
    fun `ripple delete preserves existing gaps and leaves untouched tracks unchanged`() {
        val first = clip("first", 1_000L, 0L, 500L, 500L)
        val deleted = clip("deleted", 2_000L, 0L, 500L, 500L)
        val last = clip("last", 3_000L, 0L, 400L, 400L)
        val untouched = clip("untouched", 5_000L, 0L, 300L, 300L)
        val tracks = listOf(
            Track(type = TrackType.VIDEO, index = 0, clips = listOf(first, deleted, last)),
            Track(type = TrackType.AUDIO, index = 1, clips = listOf(untouched))
        )

        val result = rippleDeleteClips(tracks, setOf("deleted"))

        assertEquals(listOf("first", "last"), result[0].clips.map { it.id })
        assertEquals(listOf(1_000L, 2_500L), result[0].clips.map { it.timelineStartMs })
        assertEquals(5_000L, result[1].clips.single().timelineStartMs)
    }

    @Test
    fun `ntsc ripple subtracts frame indices without timestamp drift`() {
        val removed = clip("removed", 33L, 0L, 34L, 34L)
        val later = clip("later", 100L, 0L, 100L, 100L)
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(removed, later)))

        val result = rippleDeleteClips(tracks, setOf(removed.id), TimelineTimebase.NTSC_29_97)

        assertEquals(67L, result.single().clips.single().timelineStartMs)
        assertEquals(
            67L,
            rippleTimelinePosition(100L, listOf(33L to 67L), TimelineTimebase.NTSC_29_97),
        )
    }

    @Test
    fun `linked ntsc trim applies the same frame delta at each absolute boundary`() {
        val first = clip("first", 33L, 0L, 500L, 500L)
        val linked = clip("linked", 100L, 0L, 500L, 500L)
        val tracks = listOf(
            Track(type = TrackType.VIDEO, index = 0, clips = listOf(first)),
            Track(type = TrackType.AUDIO, index = 1, clips = listOf(linked)),
        )

        val result = trimLinkedClipStartToTimelineTime(
            tracks,
            anchorClipId = first.id,
            targetClipIds = setOf(first.id, linked.id),
            requestedTimelineStartMs = 67L,
            timebase = TimelineTimebase.NTSC_29_97,
        )

        assertEquals(67L, result[0].clips.single().timelineStartMs)
        assertEquals(133L, result[1].clips.single().timelineStartMs)
    }

    @Test
    fun `lift delete removes clips without moving any later clip or gap`() {
        val first = clip("first", 1_000L, 0L, 500L, 500L)
        val lifted = clip("lifted", 2_000L, 0L, 500L, 500L)
        val last = clip("last", 3_000L, 0L, 400L, 400L)
        val untouched = clip("untouched", 5_000L, 0L, 300L, 300L)
        val tracks = listOf(
            Track(type = TrackType.VIDEO, index = 0, clips = listOf(first, lifted, last)),
            Track(type = TrackType.AUDIO, index = 1, clips = listOf(untouched))
        )

        val result = removeClipsWithoutRipple(tracks, setOf("lifted"))

        // The lifted clip is gone but every other clip keeps its exact position,
        // leaving the 2_000..2_500 hole intact.
        assertEquals(listOf("first", "last"), result[0].clips.map { it.id })
        assertEquals(listOf(1_000L, 3_000L), result[0].clips.map { it.timelineStartMs })
        assertEquals(5_000L, result[1].clips.single().timelineStartMs)
    }

    @Test
    fun `lift delete of an unknown id is a no-op that reuses the same track instances`() {
        val only = clip("only", 0L, 0L, 500L, 500L)
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(only)))
        assertSame(tracks[0], removeClipsWithoutRipple(tracks, setOf("missing"))[0])
    }

    @Test
    fun `timeline markers inside deleted media are removed and later markers ripple`() {
        val ranges = listOf(1_000L to 1_500L, 2_000L to 2_250L)

        assertEquals(900L, rippleTimelinePosition(900L, ranges))
        assertNull(rippleTimelinePosition(1_200L, ranges))
        assertEquals(1_300L, rippleTimelinePosition(1_800L, ranges))
        assertNull(rippleTimelinePosition(2_100L, ranges))
        assertEquals(1_750L, rippleTimelinePosition(2_500L, ranges))
    }

    @Test
    fun `preview playhead follows ripple deletes and lands at a removed clip boundary`() {
        val ranges = listOf(1_000L to 1_500L, 2_000L to 2_250L)

        assertEquals(900L, ripplePlaybackPosition(900L, ranges))
        assertEquals(1_000L, ripplePlaybackPosition(1_200L, ranges))
        assertEquals(1_300L, ripplePlaybackPosition(1_800L, ranges))
        assertEquals(1_500L, ripplePlaybackPosition(2_100L, ranges))
        assertEquals(1_750L, ripplePlaybackPosition(2_500L, ranges))
    }

    @Test
    fun `preview playhead counts overlapping delete ranges only once`() {
        val ranges = listOf(1_000L to 1_600L, 1_400L to 1_800L)

        assertEquals(1_000L, ripplePlaybackPosition(1_500L, ranges))
        assertEquals(1_200L, ripplePlaybackPosition(2_000L, ranges))
    }

    @Test
    fun `assistant range validation rejects a cut with an unsafe trailing fragment`() {
        val source = clip("source", 0L, 0L, 1_000L, 1_000L)
        val tracks = listOf(Track(type = TrackType.VIDEO, index = 0, clips = listOf(source)))

        assertTrue(canDeleteTimelineRangeAtomically(tracks, source.id, 200L, 700L))
        assertFalse(canDeleteTimelineRangeAtomically(tracks, source.id, 200L, 950L))
    }

    @Test
    fun `speed-curve split keeps the two halves exactly abutting`() {
        // A ramping speed curve makes durationMs a rounded integration of the
        // restricted curve, which used to leave a sub-frame gap/overlap between
        // the split halves and break the merge/coalesce abutment invariant.
        val ramped = clip("ramped", 1_000L, 0L, 4_000L, 4_000L, speedCurve = SpeedCurve.rampUp())
        var generatedId = 0
        val split = splitTimelineClip(
            clip = ramped,
            playheadMs = ramped.timelineStartMs + ramped.durationMs / 2,
            newClipId = "right",
            newLinkedClipId = null,
            rightGroupId = null,
            idFactory = { "generated-${generatedId++}" }
        ) ?: error("expected split")

        assertEquals(split.left.timelineEndMs, split.right.timelineStartMs)
    }

    @Test
    fun `speed-curve split shifts following clips to the reconstructed boundary`() {
        val ramped = clip("ramped", 1_000L, 0L, 4_000L, 4_000L, speedCurve = SpeedCurve.rampUp())
        val originalEndMs = ramped.timelineEndMs
        val following = clip("following", originalEndMs, 0L, 500L, 500L)
        var generatedId = 0
        val split = splitTimelineClip(
            clip = ramped,
            playheadMs = ramped.timelineStartMs + ramped.durationMs / 2,
            newClipId = "right",
            newLinkedClipId = null,
            rightGroupId = null,
            idFactory = { "generated-${generatedId++}" }
        ) ?: error("expected split")
        assertNotEquals(originalEndMs, split.right.timelineEndMs)
        val corrected = shiftFollowingClipsPreservingGaps(
            track = Track(
                type = TrackType.VIDEO,
                index = 0,
                clips = listOf(split.left, split.right, following),
            ),
            afterClipId = split.right.id,
            correctionMs = split.right.timelineEndMs - originalEndMs,
        )

        assertEquals(split.right.timelineEndMs, corrected.clips[2].timelineStartMs)
        assertEquals(corrected.clips[1].timelineEndMs, corrected.clips[2].timelineStartMs)
    }

    @Test
    fun `reversed split uses the mirrored source boundary`() {
        val reversed = clip("reversed", 1_000L, 100L, 900L, 1_000L).copy(isReversed = true)

        val split = splitTimelineClip(
            clip = reversed,
            playheadMs = 1_300L,
            newClipId = "right",
            newLinkedClipId = null,
            rightGroupId = null,
            idFactory = { "generated" }
        ) ?: error("expected split")

        assertEquals(600L, split.sourceSplitMs)
        assertEquals(600L, split.left.trimEndMs)
        assertEquals(600L, split.right.trimStartMs)
        assertEquals(split.left.timelineEndMs, split.right.timelineStartMs)
    }

    @Test
    fun `split preserves absolute animation and caption timing with fresh right-side identities`() {
        val sourceClip = clip("source", 1_000L, 0L, 1_000L, 1_000L).copy(
            groupId = "left-group",
            fadeInMs = 100L,
            fadeOutMs = 200L,
            keyframes = listOf(
                Keyframe(0L, KeyframeProperty.POSITION_X, 0f, interpolation = KeyframeInterpolation.LINEAR),
                Keyframe(1_000L, KeyframeProperty.POSITION_X, 10f, interpolation = KeyframeInterpolation.LINEAR)
            ),
            effects = listOf(
                Effect(
                    id = "effect",
                    type = EffectType.BRIGHTNESS,
                    keyframes = listOf(
                        EffectKeyframe(0L, "amount", 0f),
                        EffectKeyframe(1_000L, "amount", 1f)
                    )
                )
            ),
            masks = listOf(
                Mask(
                    id = "mask",
                    type = MaskType.RECTANGLE,
                    points = listOf(MaskPoint(0f, 0f)),
                    keyframes = listOf(
                        MaskKeyframe(0L, listOf(MaskPoint(0f, 0f))),
                        MaskKeyframe(1_000L, listOf(MaskPoint(1f, 1f)))
                    )
                )
            ),
            captions = listOf(
                Caption(
                    id = "caption",
                    text = "crosses cut",
                    startTimeMs = 400L,
                    endTimeMs = 700L,
                    words = listOf(CaptionWord("cut", 420L, 680L))
                )
            ),
            motionTrackingData = MotionTrackingData(
                id = "motion",
                trackPoints = listOf(
                    MotionTrackPoint(0L, 0f, 0f),
                    MotionTrackPoint(1_000L, 1f, 1f)
                )
            ),
            audioEffects = listOf(AudioEffect(id = "audio-fx", type = AudioEffectType.COMPRESSOR))
        )
        var generatedId = 0

        val split = splitTimelineClip(
            clip = sourceClip,
            playheadMs = 1_500L,
            newClipId = "right",
            newLinkedClipId = null,
            rightGroupId = "right-group",
            idFactory = { "generated-${generatedId++}" }
        ) ?: error("expected split")

        assertEquals(500L, split.left.durationMs)
        assertEquals(500L, split.right.durationMs)
        assertEquals(5f, split.left.keyframes.last().value, 0.01f)
        assertEquals(500L, split.left.keyframes.last().timeOffsetMs)
        assertEquals(5f, split.right.keyframes.first().value, 0.01f)
        assertEquals(0L, split.right.keyframes.first().timeOffsetMs)
        assertEquals(0.5f, split.right.effects.single().keyframes.first().value, 0.01f)
        assertFalse(split.right.effects.single().id == "effect")
        assertFalse(split.right.masks.single().id == "mask")
        assertEquals(400L, split.left.captions.single().startTimeMs)
        assertEquals(500L, split.left.captions.single().endTimeMs)
        assertEquals(0L, split.right.captions.single().startTimeMs)
        assertEquals(200L, split.right.captions.single().endTimeMs)
        assertEquals(0L, split.right.captions.single().words.single().startTimeMs)
        assertEquals(100L, split.left.fadeInMs)
        assertEquals(0L, split.left.fadeOutMs)
        assertEquals(0L, split.right.fadeInMs)
        assertEquals(200L, split.right.fadeOutMs)
        assertEquals("left-group", split.left.groupId)
        assertEquals("right-group", split.right.groupId)
        assertFalse(split.right.audioEffects.single().id == "audio-fx")
    }

    private fun clip(
        id: String,
        timelineStartMs: Long,
        trimStartMs: Long,
        trimEndMs: Long,
        sourceDurationMs: Long,
        speedCurve: SpeedCurve? = null
    ): Clip {
        return Clip(
            id = id,
            sourceUri = FakeUri,
            sourceDurationMs = sourceDurationMs,
            timelineStartMs = timelineStartMs,
            trimStartMs = trimStartMs,
            trimEndMs = trimEndMs,
            speedCurve = speedCurve
        )
    }

    private fun assertWithin(expected: Long, actual: Long, toleranceMs: Long) {
        assertTrue(
            "expected $actual to be within ${toleranceMs}ms of $expected",
            kotlin.math.abs(actual - expected) <= toleranceMs
        )
    }
}
