package com.novacut.editor.model

import android.net.FakeUri
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ClipTimingTest {

    @Test
    fun `infinite clip speed falls back to normal playback instead of collapsing duration`() {
        val clip = clip(speed = Float.POSITIVE_INFINITY)

        assertEquals(1_000L, clip.durationMs)
        assertEquals(500L, clip.timelineOffsetToSourceMs(500L))
        assertEquals(500L, clip.sourceTimeToTimelineOffsetMs(500L))
    }

    @Test
    fun `speed curve ignores non finite points and handles`() {
        val clip = clip(
            speedCurve = SpeedCurve(
                listOf(
                    SpeedPoint(0f, 1f, handleOutY = Float.NaN),
                    SpeedPoint(Float.NaN, 0.5f),
                    SpeedPoint(1f, Float.POSITIVE_INFINITY, handleInY = Float.NEGATIVE_INFINITY)
                )
            )
        )

        assertEquals(1_000L, clip.durationMs)
        assertTrue(clip.getEffectiveSpeed(500L).isFinite())
        assertWithin(500L, clip.timelineOffsetToSourceMs(500L), toleranceMs = 2L)
    }

    @Test
    fun `source time maps back to timeline offset for speed curves`() {
        val clip = clip(speedCurve = SpeedCurve.constant(2f))

        assertEquals(500L, clip.durationMs)
        assertWithin(250L, clip.sourceTimeToTimelineOffsetMs(500L) ?: -1L, toleranceMs = 2L)
        assertWithin(500L, clip.timelineOffsetToSourceMs(250L), toleranceMs = 2L)
    }

    @Test
    fun `reversed clips map timeline positions from the trimmed source end`() {
        val clip = clip().copy(
            trimStartMs = 200L,
            trimEndMs = 800L,
            isReversed = true,
        )

        assertEquals(800L, clip.timelineOffsetToSourceMs(0L))
        assertEquals(500L, clip.timelineOffsetToSourceMs(300L))
        assertEquals(200L, clip.timelineOffsetToSourceMs(600L))
        assertEquals(0L, clip.sourceTimeToTimelineOffsetMs(800L))
        assertEquals(600L, clip.sourceTimeToTimelineOffsetMs(200L))
    }

    @Test
    fun `eased speed ramp duration integrates wall clock curve`() {
        val clip = clip(speedCurve = SpeedCurve.rampUp(from = 0.5f, to = 2f))

        assertWithin(930L, clip.durationMs, toleranceMs = 2L)
        val timelineMidpoint = clip.sourceTimeToTimelineOffsetMs(500L) ?: -1L
        assertWithin(618L, timelineMidpoint, toleranceMs = 3L)
        assertWithin(500L, clip.timelineOffsetToSourceMs(timelineMidpoint), toleranceMs = 3L)
    }

    @Test
    fun `long recordings keep millisecond precision at constant speed`() {
        // Long / Float division loses ms precision past ~2^24 ms (~4.66 h);
        // a 12 h dashcam clip must not drift against the Double-based
        // offset mappers.
        val twelveHoursMs = 12L * 60L * 60L * 1000L
        val clip = Clip(
            sourceUri = FakeUri,
            sourceDurationMs = twelveHoursMs,
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = twelveHoursMs,
            speed = 1f
        )

        assertEquals(twelveHoursMs, clip.durationMs)
    }

    @Test
    fun `audio sync offsets are signed frame quantized and audio track only`() {
        val clip = clip().copy(audioSyncOffsetMs = 500L)
        val audioTrack = Track(type = TrackType.AUDIO, index = 0, clips = listOf(clip))
        val videoTrack = Track(type = TrackType.VIDEO, index = 1, clips = listOf(clip))

        assertEquals(500L, audioTrack.effectiveTimelineStartMs(clip))
        assertEquals(0L, videoTrack.effectiveTimelineStartMs(clip))
        assertEquals(33L, quantizeClipAudioSyncOffsetMs(17L, TimelineTimebase(30)))
        assertEquals(-33L, quantizeClipAudioSyncOffsetMs(-17L, TimelineTimebase(30)))
    }

    @Test
    fun `fractional frame-rate sync limits remain frame aligned at both bounds`() {
        val timebase = TimelineTimebase.NTSC_23_976
        val maximumGridAlignedOffset = timebase.timeMsAt(
            timebase.frameIndexAtOrBefore(MAX_CLIP_AUDIO_SYNC_OFFSET_MS)
        )

        assertTrue(maximumGridAlignedOffset < MAX_CLIP_AUDIO_SYNC_OFFSET_MS)
        assertEquals(
            maximumGridAlignedOffset,
            quantizeClipAudioSyncOffsetMs(MAX_CLIP_AUDIO_SYNC_OFFSET_MS, timebase),
        )
        assertEquals(
            -maximumGridAlignedOffset,
            quantizeClipAudioSyncOffsetMs(MIN_CLIP_AUDIO_SYNC_OFFSET_MS, timebase),
        )
        assertEquals(
            maximumGridAlignedOffset,
            timebase.snapMs(maximumGridAlignedOffset),
        )
    }

    private fun assertWithin(expected: Long, actual: Long, toleranceMs: Long) {
        assertTrue(
            "expected $actual to be within ${toleranceMs}ms of $expected",
            kotlin.math.abs(actual - expected) <= toleranceMs
        )
    }

    private fun clip(
        speed: Float = 1f,
        speedCurve: SpeedCurve? = null
    ): Clip {
        return Clip(
            sourceUri = FakeUri,
            sourceDurationMs = 1_000L,
            timelineStartMs = 0L,
            trimStartMs = 0L,
            trimEndMs = 1_000L,
            speed = speed,
            speedCurve = speedCurve
        )
    }
}
