package com.novacut.editor.engine

import android.net.FakeUri
import android.net.TestUri
import com.novacut.editor.model.AudioEffect
import com.novacut.editor.model.AudioEffectType
import com.novacut.editor.model.Clip
import com.novacut.editor.model.Effect
import com.novacut.editor.model.EffectKeyframe
import com.novacut.editor.model.EffectType
import com.novacut.editor.model.Keyframe
import com.novacut.editor.model.KeyframeInterpolation
import com.novacut.editor.model.KeyframeProperty
import com.novacut.editor.model.ProjectColorPolicy
import com.novacut.editor.model.SpeedCurve
import com.novacut.editor.model.SpeedPoint
import com.novacut.editor.model.TextOverlay
import com.novacut.editor.model.Track
import com.novacut.editor.model.TrackType
import com.novacut.editor.model.Watermark
import com.novacut.editor.model.WatermarkPosition
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoSaveStateTest {

    @Test
    fun mutedVolumeKeyframesRoundTripThroughAutosave() {
        val state = AutoSaveState(
            projectId = "mute-range-project",
            tracks = listOf(
                Track(
                    type = TrackType.AUDIO,
                    index = 0,
                    clips = listOf(
                        Clip(
                            sourceUri = FakeUri,
                            sourceDurationMs = 2_000L,
                            timelineStartMs = 0L,
                            trimStartMs = 0L,
                            trimEndMs = 2_000L,
                            keyframes = listOf(
                                Keyframe(
                                    timeOffsetMs = 499L,
                                    property = KeyframeProperty.VOLUME,
                                    value = 1f,
                                    interpolation = KeyframeInterpolation.HOLD,
                                ),
                                Keyframe(
                                    timeOffsetMs = 500L,
                                    property = KeyframeProperty.VOLUME,
                                    value = 0f,
                                    interpolation = KeyframeInterpolation.HOLD,
                                ),
                                Keyframe(
                                    timeOffsetMs = 1_000L,
                                    property = KeyframeProperty.VOLUME,
                                    value = 1f,
                                    interpolation = KeyframeInterpolation.HOLD,
                                ),
                            ),
                        )
                    ),
                )
            ),
        )

        val restored = AutoSaveState.deserialize(state.serialize()) { FakeUri }
        val keyframes = restored.tracks.single().clips.single().keyframes

        assertEquals(state.tracks.single().clips.single().keyframes, keyframes)
        assertEquals(KeyframeInterpolation.HOLD, keyframes[1].interpolation)
        assertEquals(KeyframeProperty.VOLUME, keyframes[1].property)
    }

    @Test
    fun exportWatermarkRoundTripsWithoutSubstitution() {
        val source = TestUri(
            raw = "content://brand-assets/logo.png",
            schemeValue = "content",
            segment = "logo.png"
        )
        val state = AutoSaveState(
            projectId = "watermark-project",
            exportWatermark = Watermark(
                sourceUri = source,
                position = WatermarkPosition.TOP_RIGHT,
                opacity = 0.55f,
                scalePercent = 27
            )
        )

        val restored = AutoSaveState.deserialize(state.serialize()) { raw ->
            TestUri(raw = raw, schemeValue = raw.substringBefore(':'), segment = raw.substringAfterLast('/'))
        }

        assertEquals(source.toString(), restored.exportWatermark?.sourceUri.toString())
        assertEquals(WatermarkPosition.TOP_RIGHT, restored.exportWatermark?.position)
        assertEquals(0.55f, restored.exportWatermark?.opacity)
        assertEquals(27, restored.exportWatermark?.scalePercent)
    }

    @Test
    fun projectColorPolicy_roundTripsAndOlderProjectsLoadAsSdr() {
        val state = AutoSaveState(projectId = "color-project", colorPolicy = ProjectColorPolicy.KEEP_HDR)

        val restored = AutoSaveState.deserialize(state.serialize()) { FakeUri }
        assertEquals(ProjectColorPolicy.KEEP_HDR, restored.colorPolicy)

        val oldJson = JSONObject(state.serialize()).apply { remove("colorPolicy") }
        val restoredOld = AutoSaveState.deserialize(oldJson.toString()) { FakeUri }
        assertEquals(ProjectColorPolicy.DEFAULT, restoredOld.colorPolicy)
    }

    @Test
    fun trackTimelineOffset_roundTripsAndDefaultsForOlderDocuments() {
        val state = AutoSaveState(
            projectId = "offset-project",
            tracks = listOf(
                Track(
                    type = TrackType.AUDIO,
                    index = 0,
                    timelineOffsetMs = 1_234L,
                )
            ),
        )

        val restored = AutoSaveState.deserialize(state.serialize()) { FakeUri }
        assertEquals(1_234L, restored.tracks.single().timelineOffsetMs)

        val oldJson = JSONObject(state.serialize()).apply {
            getJSONArray("tracks").getJSONObject(0).remove("timelineOffsetMs")
        }
        val restoredOld = AutoSaveState.deserialize(oldJson.toString()) { FakeUri }
        assertEquals(0L, restoredOld.tracks.single().timelineOffsetMs)
    }

    @Test
    fun clipAudioSyncOffset_roundTripsAndDefaultsForOlderDocuments() {
        val state = AutoSaveState(
            projectId = "clip-offset-project",
            tracks = listOf(
                Track(
                    type = TrackType.AUDIO,
                    index = 0,
                    clips = listOf(
                        Clip(
                            sourceUri = FakeUri,
                            sourceDurationMs = 4_000L,
                            timelineStartMs = 0L,
                            audioSyncOffsetMs = -3_000L,
                            trimEndMs = 4_000L,
                        )
                    ),
                )
            ),
        )

        val serialized = JSONObject(state.serialize())
        val serializedClip = serialized.getJSONArray("tracks")
            .getJSONObject(0)
            .getJSONArray("clips")
            .getJSONObject(0)
        assertEquals(-3_000L, serializedClip.getLong("audioSyncOffsetMs"))

        val restored = AutoSaveState.deserialize(serialized.toString()) { FakeUri }
        assertEquals(-3_000L, restored.tracks.single().clips.single().audioSyncOffsetMs)

        serializedClip.remove("audioSyncOffsetMs")
        val restoredOld = AutoSaveState.deserialize(serialized.toString()) { FakeUri }
            .tracks.single().clips.single()
        assertEquals(0L, restoredOld.audioSyncOffsetMs)
    }

    @Test
    fun clipFlipAxes_roundTripAndDefaultOffForOlderDocuments() {
        val state = AutoSaveState(
            projectId = "flip-project",
            tracks = listOf(
                Track(
                    type = TrackType.VIDEO,
                    index = 0,
                    clips = listOf(
                        Clip(
                            sourceUri = FakeUri,
                            sourceDurationMs = 1_000L,
                            timelineStartMs = 0L,
                            trimEndMs = 1_000L,
                            flipHorizontal = true,
                            flipVertical = true,
                        )
                    ),
                )
            ),
        )

        val serialized = JSONObject(state.serialize())
        val serializedClip = serialized.getJSONArray("tracks")
            .getJSONObject(0)
            .getJSONArray("clips")
            .getJSONObject(0)
        assertTrue(serializedClip.getBoolean("flipHorizontal"))
        assertTrue(serializedClip.getBoolean("flipVertical"))

        val restored = AutoSaveState.deserialize(serialized.toString()) { FakeUri }
        val restoredClip = restored.tracks.single().clips.single()
        assertTrue(restoredClip.flipHorizontal)
        assertTrue(restoredClip.flipVertical)

        serializedClip.remove("flipHorizontal")
        serializedClip.remove("flipVertical")
        val restoredOld = AutoSaveState.deserialize(serialized.toString()) { FakeUri }
            .tracks.single().clips.single()
        assertFalse(restoredOld.flipHorizontal)
        assertFalse(restoredOld.flipVertical)
    }

    @Test
    fun deserialize_coercesTrackFieldsToModelInvariants() {
        val state = AutoSaveState.deserialize(
            """
            {
              "version": 1,
              "projectId": "project",
              "tracks": [
                {
                  "id": "track",
                  "type": "VIDEO",
                  "index": -4,
                  "pan": 9.0,
                  "volume": 9.0,
                  "opacity": -3.0,
                  "trackHeight": 1,
                  "clips": []
                }
              ],
              "textOverlays": []
            }
            """.trimIndent()
        )

        val track = state.tracks.single()
        assertEquals(0, track.index)
        assertEquals(1f, track.pan, 0.0001f)
        assertEquals(2f, track.volume, 0.0001f)
        assertEquals(0f, track.opacity, 0.0001f)
        assertEquals(32, track.trackHeight)
    }

    @Test
    fun deserialize_preservesTextOverlayWhenRecoveredNumbersAreInvalid() {
        val state = AutoSaveState.deserialize(
            """
            {
              "version": 1,
              "projectId": "project",
              "tracks": [],
              "textOverlays": [
                {
                  "id": "title",
                  "text": "Recovered title",
                  "fontSize": 0,
                  "positionX": 999,
                  "positionY": -999,
                  "startTimeMs": 5000,
                  "endTimeMs": 1000,
                  "scaleX": 0,
                  "scaleY": -1,
                  "shadowBlur": -10,
                  "glowRadius": -10,
                  "lineHeight": 0
                }
              ]
            }
            """.trimIndent()
        )

        val overlay = state.textOverlays.single()
        assertEquals("Recovered title", overlay.text)
        assertTrue(overlay.fontSize > 0f)
        assertEquals(5_000L, overlay.startTimeMs)
        assertEquals(5_001L, overlay.endTimeMs)
        assertEquals(5f, overlay.positionX, 0.0001f)
        assertEquals(-5f, overlay.positionY, 0.0001f)
        assertTrue(overlay.scaleX > 0f)
        assertTrue(overlay.scaleY > 0f)
        assertEquals(0f, overlay.shadowBlur, 0.0001f)
        assertEquals(0f, overlay.glowRadius, 0.0001f)
        assertTrue(overlay.lineHeight > 0f)
    }

    @Test
    fun serialize_replacesNonFiniteFloatsBeforeWritingJson() {
        val state = AutoSaveState(
            projectId = "project",
            tracks = listOf(
                Track(
                    type = TrackType.VIDEO,
                    index = 0,
                    volume = Float.NaN,
                    opacity = Float.POSITIVE_INFINITY,
                    audioEffects = listOf(
                        AudioEffect(
                            type = AudioEffectType.PARAMETRIC_EQ,
                            params = mapOf("band1_gain" to Float.NEGATIVE_INFINITY)
                        )
                    ),
                    clips = listOf(
                        Clip(
                            sourceUri = FakeUri,
                            sourceDurationMs = 1_000L,
                            timelineStartMs = 0L,
                            trimStartMs = 0L,
                            trimEndMs = 1_000L,
                            speed = Float.POSITIVE_INFINITY,
                            rotation = Float.NaN,
                            scaleX = Float.POSITIVE_INFINITY,
                            effects = listOf(
                                Effect(
                                    type = EffectType.BRIGHTNESS,
                                    params = mapOf("amount" to Float.NaN),
                                    keyframes = listOf(
                                        EffectKeyframe(
                                            timeOffsetMs = 100L,
                                            paramName = "amount",
                                            value = Float.POSITIVE_INFINITY,
                                            handleInX = Float.NaN
                                        )
                                    )
                                )
                            ),
                            keyframes = listOf(
                                Keyframe(
                                    timeOffsetMs = 200L,
                                    property = KeyframeProperty.OPACITY,
                                    value = Float.NaN,
                                    handleOutY = Float.POSITIVE_INFINITY
                                )
                            ),
                            speedCurve = SpeedCurve(
                                listOf(
                                    SpeedPoint(Float.NaN, Float.POSITIVE_INFINITY),
                                    SpeedPoint(1f, 1f, handleInY = Float.NaN)
                                )
                            )
                        )
                    )
                )
            ),
            textOverlays = listOf(
                TextOverlay(
                    text = "Title",
                    fontSize = Float.POSITIVE_INFINITY,
                    positionX = Float.NaN,
                    lineHeight = Float.NEGATIVE_INFINITY
                )
            ),
            drawingPaths = listOf(
                com.novacut.editor.model.DrawingPath(
                    points = listOf(Float.NaN to Float.POSITIVE_INFINITY, 1f to 1f),
                    color = 0xFFFFFFFF,
                    strokeWidth = Float.NaN
                )
            )
        )

        val serialized = state.serialize()

        assertFalse(serialized.contains("NaN"))
        assertFalse(serialized.contains("Infinity"))

        val root = JSONObject(serialized)
        val track = root.getJSONArray("tracks").getJSONObject(0)
        val clip = track.getJSONArray("clips").getJSONObject(0)
        val effect = clip.getJSONArray("effects").getJSONObject(0)
        val overlay = root.getJSONArray("textOverlays").getJSONObject(0)
        val drawingPath = root.getJSONArray("drawingPaths").getJSONObject(0)

        assertEquals(1.0, track.getDouble("volume"), 0.0001)
        assertEquals(1.0, track.getDouble("opacity"), 0.0001)
        assertEquals(0.0, track.getJSONArray("audioEffects").getJSONObject(0).getJSONObject("params").getDouble("band1_gain"), 0.0001)
        assertEquals(1.0, clip.getDouble("speed"), 0.0001)
        assertEquals(0.0, clip.getDouble("rotation"), 0.0001)
        assertEquals(1.0, clip.getDouble("scaleX"), 0.0001)
        assertEquals(0.0, effect.getJSONObject("params").getDouble("amount"), 0.0001)
        assertEquals(1.0, effect.getJSONArray("keyframes").getJSONObject(0).getDouble("value"), 0.0001)
        assertEquals(1.0, clip.getJSONArray("keyframes").getJSONObject(0).getDouble("value"), 0.0001)
        assertEquals(48.0, overlay.getDouble("fontSize"), 0.0001)
        assertEquals(0.5, overlay.getDouble("positionX"), 0.0001)
        assertEquals(1.2, overlay.getDouble("lineHeight"), 0.0001)
        assertEquals(4.0, drawingPath.getDouble("strokeWidth"), 0.0001)
    }

    @Test
    fun serialize_writesTrackedEffectTarget() {
        val state = AutoSaveState(
            projectId = "project",
            tracks = listOf(
                Track(
                    type = TrackType.VIDEO,
                    index = 0,
                    clips = listOf(
                        Clip(
                            sourceUri = FakeUri,
                            sourceDurationMs = 1_000L,
                            timelineStartMs = 0L,
                            trimStartMs = 0L,
                            trimEndMs = 1_000L,
                            effects = listOf(
                                Effect(
                                    type = EffectType.TRACKED_MOSAIC,
                                    params = EffectType.defaultParams(EffectType.TRACKED_MOSAIC),
                                    targetTrackedObjectId = "tracked-face"
                                )
                            )
                        )
                    )
                )
            )
        )

        val effect = JSONObject(state.serialize())
            .getJSONArray("tracks")
            .getJSONObject(0)
            .getJSONArray("clips")
            .getJSONObject(0)
            .getJSONArray("effects")
            .getJSONObject(0)

        assertEquals(EffectType.TRACKED_MOSAIC.name, effect.getString("type"))
        assertEquals("tracked-face", effect.getString("targetTrackedObjectId"))
    }

    @Test
    fun serialize_writesMediaAssetsAndClipAssetIds() {
        val state = AutoSaveState(
            projectId = "project",
            mediaAssets = listOf(
                ProjectMediaAsset(
                    assetId = "asset-media",
                    managedUri = "file:///managed/clip.mp4",
                    originalUri = "content://source/clip",
                    displayName = "clip.mp4",
                    mediaType = "video",
                    mimeType = "video/mp4",
                    sizeBytes = 1234L,
                    durationMs = 5000L,
                    width = 1920,
                    height = 1080,
                    quickFingerprint = "fingerprint",
                    importStatus = "ready",
                    lastVerifiedAtEpochMs = 99L,
                    notes = "Interview selects",
                    tags = listOf("interview", "b-roll")
                )
            ),
            tracks = listOf(
                Track(
                    type = TrackType.VIDEO,
                    index = 0,
                    clips = listOf(
                        Clip(
                            assetId = "asset-media",
                            sourceUri = FakeUri,
                            sourceDurationMs = 5_000L,
                            timelineStartMs = 0L
                        )
                    )
                )
            )
        )

        val root = JSONObject(state.serialize())
        val asset = root.getJSONArray("mediaAssets").getJSONObject(0)
        val clip = root.getJSONArray("tracks")
            .getJSONObject(0)
            .getJSONArray("clips")
            .getJSONObject(0)

        assertEquals("asset-media", asset.getString("assetId"))
        assertEquals("file:///managed/clip.mp4", asset.getString("managedUri"))
        assertEquals("ready", asset.getString("importStatus"))
        assertEquals("Interview selects", asset.getString("notes"))
        assertEquals(listOf("b-roll", "interview"), (0 until asset.getJSONArray("tags").length()).map {
            asset.getJSONArray("tags").getString(it)
        })
        assertEquals("asset-media", clip.getString("assetId"))
    }

    @Test
    fun deserialize_restoresMediaAssetsAndClipAssetIds() {
        val root = JSONObject().apply {
            put("version", AutoSaveState.FORMAT_VERSION)
            put("projectId", "project")
            put("mediaAssets", JSONArray().put(JSONObject().apply {
                put("assetId", "asset-media")
                put("managedUri", "file:///managed/clip.mp4")
                put("originalUri", "content://source/clip")
                put("mediaType", "video")
                put("importStatus", "ready")
                put("notes", "Keep this")
                put("tags", JSONArray().put("selects"))
            }))
            put("tracks", JSONArray().put(JSONObject().apply {
                put("type", TrackType.VIDEO.name)
                put("index", 0)
                put("clips", JSONArray().put(JSONObject().apply {
                    put("id", "clip")
                    put("assetId", "asset-media")
                    put("sourceUri", FakeUri.toString())
                    put("sourceDurationMs", 5_000L)
                    put("trimStartMs", 0L)
                    put("trimEndMs", 5_000L)
                    put("effects", JSONArray())
                    put("keyframes", JSONArray())
                }))
            }))
        }

        val state = AutoSaveState.deserialize(root.toString(), uriParser = { FakeUri })

        assertEquals("asset-media", state.mediaAssets.single().assetId)
        assertEquals("Keep this", state.mediaAssets.single().notes)
        assertEquals(listOf("selects"), state.mediaAssets.single().tags)
        assertEquals("asset-media", state.tracks.single().clips.single().assetId)
    }

    @Test
    fun deserialize_recoversClipSourceUriFromAssetIdWhenSourceUriMissing() {
        val managedUri = "file:///managed/clip.mp4"
        val root = JSONObject().apply {
            put("version", AutoSaveState.FORMAT_VERSION)
            put("projectId", "project")
            put("mediaAssets", JSONArray().put(JSONObject().apply {
                put("assetId", "asset-media")
                put("managedUri", managedUri)
                put("mediaType", "video")
                put("importStatus", "ready")
            }))
            put("tracks", JSONArray().put(JSONObject().apply {
                put("type", TrackType.VIDEO.name)
                put("index", 0)
                put("clips", JSONArray().put(JSONObject().apply {
                    put("id", "clip")
                    put("assetId", "asset-media")
                    put("sourceDurationMs", 5_000L)
                    put("trimStartMs", 0L)
                    put("trimEndMs", 5_000L)
                    put("effects", JSONArray())
                    put("keyframes", JSONArray())
                }))
            }))
        }

        val state = AutoSaveState.deserialize(
            root.toString(),
            uriParser = { raw ->
                TestUri(
                    raw = raw,
                    schemeValue = raw.substringBefore(":", "file"),
                    segment = raw.substringAfterLast('/')
                )
            }
        )

        val clip = state.tracks.single().clips.single()
        assertEquals("asset-media", clip.assetId)
        assertEquals(managedUri, clip.sourceUri.toString())
    }

    @Test
    fun deserialize_prefersManagedAssetUriOverStaleSerializedSourceUri() {
        val managedUri = "file:///managed/clip.mp4"
        val staleSourceUri = "content://source/stale"
        val root = JSONObject().apply {
            put("version", AutoSaveState.FORMAT_VERSION)
            put("projectId", "project")
            put("mediaAssets", JSONArray().put(JSONObject().apply {
                put("assetId", "asset-media")
                put("managedUri", managedUri)
                put("originalUri", staleSourceUri)
                put("mediaType", "video")
                put("importStatus", "ready")
            }))
            put("tracks", JSONArray().put(JSONObject().apply {
                put("type", TrackType.VIDEO.name)
                put("index", 0)
                put("clips", JSONArray().put(JSONObject().apply {
                    put("id", "clip")
                    put("assetId", "asset-media")
                    put("sourceUri", staleSourceUri)
                    put("sourceDurationMs", 5_000L)
                    put("trimStartMs", 0L)
                    put("trimEndMs", 5_000L)
                    put("effects", JSONArray())
                    put("keyframes", JSONArray())
                }))
            }))
        }

        val state = AutoSaveState.deserialize(
            root.toString(),
            uriParser = { raw ->
                TestUri(
                    raw = raw,
                    schemeValue = raw.substringBefore(":", "file"),
                    segment = raw.substringAfterLast('/')
                )
            }
        )

        val clip = state.tracks.single().clips.single()
        assertEquals("asset-media", clip.assetId)
        assertEquals(managedUri, clip.sourceUri.toString())
    }

    @Test
    fun collectMediaReferenceUris_includesManagedAssetUris() {
        val root = JSONObject().apply {
            put("tracks", JSONArray().put(JSONObject().apply {
                put("clips", JSONArray().put(JSONObject().apply {
                    put("sourceUri", "content://source/stale")
                }))
            }))
            put("mediaAssets", JSONArray().put(JSONObject().apply {
                put("assetId", "asset-media")
                put("managedUri", "file:///managed/clip.mp4")
                put("originalUri", "content://source/stale")
            }))
        }

        assertEquals(
            setOf("content://source/stale", "file:///managed/clip.mp4"),
            collectMediaReferenceUrisFromAutoSaveJson(root.toString())
        )
    }

    @Test
    fun deserialize_capsPathologicalRecoveredCollections() {
        val textOverlays = JSONArray().apply {
            repeat(5_010) { index ->
                put(JSONObject().apply {
                    put("id", "text-$index")
                    put("text", "Title $index")
                    put("startTimeMs", 0)
                    put("endTimeMs", 1000)
                })
            }
        }
        val effects = JSONArray().apply {
            repeat(300) {
                put(JSONObject().apply {
                    put("type", EffectType.BRIGHTNESS.name)
                    put("params", JSONObject())
                })
            }
        }
        val clip = JSONObject().apply {
            put("id", "clip")
            put("sourceUri", FakeUri.toString())
            put("sourceDurationMs", 1_000)
            put("trimStartMs", 0)
            put("trimEndMs", 1_000)
            put("effects", effects)
        }
        val root = JSONObject().apply {
            put("version", 1)
            put("projectId", "project")
            put("tracks", JSONArray().apply {
                put(JSONObject().apply {
                    put("id", "track")
                    put("type", TrackType.VIDEO.name)
                    put("index", 0)
                    put("clips", JSONArray().put(clip))
                })
            })
            put("textOverlays", textOverlays)
        }

        val state = AutoSaveState.deserialize(root.toString(), uriParser = { FakeUri })

        assertEquals(5_000, state.textOverlays.size)
        assertEquals(256, state.tracks.single().clips.single().effects.size)
    }
}
