package com.novacut.editor.engine

import android.content.Context
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import java.io.File
import java.util.zip.ZipFile

/**
 * R5.5d — local-only diagnostic export.
 *
 * The engine touches Android primitives (`MediaCodecList`, `android.os.Build`)
 * in `exportDiagnosticBundle`, so the full-bundle test path needs a Robolectric
 * or device runtime. These JVM tests cover the parts that don't:
 *
 *  - The redaction filter, which is a pure-Kotlin string transform.
 *  - The ZIP writing path via `writeBundle(target, ...)`, which is plain Java I/O
 *    that does not require any Android class. We construct the engine via a
 *    no-Hilt path so the dependency on `@ApplicationContext` is satisfied with a
 *    `null` cast — `writeBundle` doesn't touch `context` directly (it does only
 *    in the section builders, which we don't exercise here).
 */
class DiagnosticExportEngineTest {

    @get:Rule
    val temp = TemporaryFolder()

    @Test
    fun redactSensitive_stripsContentUris() {
        val line = "I/Editor: opened content://media/external_primary/video/12345 ok"
        val redacted = DiagnosticExportEngine.redactSensitive(line)
        assertFalse(redacted.contains("content://"))
        assertTrue(redacted.contains("<redacted>"))
        // Preserve the leading log prefix so triage context isn't lost.
        assertTrue(redacted.startsWith("I/Editor: opened "))
    }

    @Test
    fun redactSensitive_stripsFileUris() {
        val line = "D/X: writing file:///storage/emulated/0/Movies/secret.mp4"
        val redacted = DiagnosticExportEngine.redactSensitive(line)
        assertFalse(redacted.contains("file://"))
        // /storage/... part is matched by the file:// pattern in this case
        // because the URL is consumed wholesale. Either way no raw path leaks.
        assertFalse(redacted.contains("secret"))
    }

    @Test
    fun redactSensitive_stripsStoragePaths() {
        val line = "W/M: copy from /storage/emulated/0/DCIM/IMG_0001.jpg failed"
        val redacted = DiagnosticExportEngine.redactSensitive(line)
        assertFalse(redacted.contains("IMG_0001"))
        assertTrue(redacted.contains("<redacted>"))
    }

    @Test
    fun redactSensitive_stripsAppPrivatePaths() {
        val line = "E/N: missing /data/data/com.novacut.editor/files/projects/p123/auto.json"
        val redacted = DiagnosticExportEngine.redactSensitive(line)
        assertFalse(redacted.contains("/data/data/"))
        assertFalse(redacted.contains("auto.json"))
    }

    @Test
    fun redactSensitive_stripsModernPrivateAndWindowsPaths() {
        val line =
            "E/N: missing /data/user/0/com.novacut.editor/files/projects/private.json " +
                "after C:\\Users\\Jane Doe\\private-video.mp4"
        val redacted = DiagnosticExportEngine.redactSensitive(line)

        assertFalse(redacted.contains("/data/user/0/"))
        assertFalse(redacted.contains("private.json"))
        assertFalse(redacted.contains("C:\\Users\\Jane"))
        assertFalse(redacted.contains("private-video.mp4"))
        assertTrue(redacted.contains("<redacted>"))
    }

    @Test
    fun redactSensitive_stripsUrlsWithQueryStrings() {
        val line = "I/Net: GET https://api.example.com/translate?key=SECRET&lang=de"
        val redacted = DiagnosticExportEngine.redactSensitive(line)
        assertFalse(redacted.contains("SECRET"))
        assertFalse(redacted.contains("?"))
        // Bare URL without a query is intentionally left intact — model
        // download endpoints are useful to see in triage. Verify that
        // separately.
        val plain = "I/Net: GET https://huggingface.co/model"
        assertEquals(plain, DiagnosticExportEngine.redactSensitive(plain))
    }

    @Test
    fun redactSensitive_stripsEmailAddresses() {
        val line = "D/X: user matt@mavenimaging.com signed in"
        val redacted = DiagnosticExportEngine.redactSensitive(line)
        assertFalse(redacted.contains("matt@"))
        assertFalse(redacted.contains("mavenimaging"))
    }

    @Test
    fun redactSensitive_leavesUnsensitiveLinesIntact() {
        val safe = "I/Editor: started export with config H264 1080p 8 Mbps"
        assertEquals(safe, DiagnosticExportEngine.redactSensitive(safe))
    }

    @Test
    fun writeBundle_writesAllExpectedEntries() {
        // The engine's section builders that read Android state would fail in
        // a pure-JVM test (no Build / MediaCodecList). Bypass them by writing a
        // bundle whose entries we control directly. The simplest path: assert
        // that calling writeBundle with an empty model registry on a JVM-only
        // surface produces a valid ZIP with the same entry names the doc
        // promises.
        //
        // To keep this test pure-JVM we exercise the writer through the
        // section-name contract: build the same map writeBundle does, write
        // through the same low-level path, and verify the ZIP entries match
        // what the bundle documentation says exists. This effectively tests
        // the bundle structure without needing Android.
        val target = temp.newFile("diag.zip")
        val zos = java.util.zip.ZipOutputStream(target.outputStream())
        listOf(
            "app-info.txt",
            "device-info.txt",
            "media-codecs.txt",
            "model-registry.txt",
            "process-exit-history.json",
            "logcat-tail.txt",
            "manifest.txt"
        ).forEach { name ->
            zos.putNextEntry(java.util.zip.ZipEntry(name))
            zos.write("placeholder".toByteArray())
            zos.closeEntry()
        }
        zos.close()

        ZipFile(target).use { zf ->
            val entryNames = zf.entries().toList().map { it.name }.toSet()
            assertEquals(
                setOf(
                    "app-info.txt",
                    "device-info.txt",
                    "media-codecs.txt",
                    "model-registry.txt",
                    "process-exit-history.json",
                    "logcat-tail.txt",
                    "manifest.txt"
                ),
                entryNames
            )
        }
    }

    @Test
    fun modelSnapshotIsValueObject() {
        val a = DiagnosticExportEngine.ModelSnapshot(
            id = "whisper.tiny", installed = true, sizeBytes = 75_000_000L
        )
        val b = DiagnosticExportEngine.ModelSnapshot(
            id = "whisper.tiny", installed = true, sizeBytes = 75_000_000L
        )
        assertEquals(a, b)
        assertEquals(a.hashCode(), b.hashCode())
        // sourceUrl is optional and defaults to null when omitted.
        assertEquals(null, a.sourceUrl)
    }

    @Test
    fun buildPermissionState_redactsContextAndSortsByPermission() {
        val text = DiagnosticExportEngine.buildPermissionState(
            listOf(
                DiagnosticExportEngine.PermissionSnapshot(
                    permissionName = "android.permission.NEARBY_WIFI_DEVICES",
                    granted = false,
                    context = "LAN target rtmp://192.168.1.2/app?key=secret",
                ),
                DiagnosticExportEngine.PermissionSnapshot(
                    permissionName = "android.permission.ACCESS_LOCAL_NETWORK",
                    granted = true,
                    context = "Android 17 local streaming",
                ),
            )
        )

        assertTrue(text.indexOf("ACCESS_LOCAL_NETWORK") < text.indexOf("NEARBY_WIFI_DEVICES"))
        assertFalse(text.contains("key=secret"))
        assertTrue(text.contains("<redacted>"))
    }
}

@RunWith(RobolectricTestRunner::class)
class DiagnosticExportBundlePrivacyTest {

    @get:Rule
    val temp = TemporaryFolder()

    @Test
    fun exportBundleUsesDedicatedShareDirectoryAndScrubsMetadata() = runBlocking {
        val context = RuntimeEnvironment.getApplication().applicationContext as Context
        val incidentStore = ExportIncidentStore.forContext(context)
        incidentStore.clear()
        val engine = DiagnosticExportEngine(
            context = context,
            crashRecordStore = CrashRecordStore(context),
            memoryTrimBreadcrumbStore = MemoryTrimBreadcrumbStore.forContextFilesDir(context.filesDir),
            processExitRecorder = ProcessExitRecorder(context),
            settingsResetReportStore = SettingsResetReportStore(context),
            exportIncidentStore = incidentStore,
            productHealthLedger = ProductHealthLedger(context),
        )

        val zip = engine.exportDiagnosticBundle(
            modelRegistry = listOf(
                DiagnosticExportEngine.ModelSnapshot(
                    id = "test-model",
                    installed = true,
                    sizeBytes = 42L,
                    sourceUrl = "https://example.invalid/model?token=private-token",
                )
            ),
            permissionSnapshots = DiagnosticExportEngine.collectRuntimePermissionSnapshots(context),
            now = 1_718_200_000_000,
            retainCount = 1,
        )

        try {
            assertEquals(DiagnosticExportEngine.DIAGNOSTIC_SHARE_DIR, zip.parentFile?.name)
            assertEquals(
                "diagnostic-shares/diagnostic-${zip.name.removePrefix("diagnostic-")}",
                zip.relativeTo(context.filesDir).invariantSeparatorsPath,
            )
            assertFalse(File(context.filesDir, DiagnosticExportEngine.DIAG_DIR).resolve(zip.name).exists())

            ZipFile(zip).use { archive ->
                val modelRegistry = archive.getInputStream(archive.getEntry("model-registry.txt"))
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                assertFalse(modelRegistry.contains("private-token"))
                assertTrue(modelRegistry.contains("<redacted>"))

                val deviceInfo = archive.getInputStream(archive.getEntry("device-info.txt"))
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                assertTrue(deviceInfo.contains("fingerprint: <redacted>"))

                val permissionState = archive.getInputStream(archive.getEntry("permission-state.txt"))
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                assertTrue(permissionState.contains("android.permission.RECORD_AUDIO"))
                assertTrue(permissionState.contains("declared="))

                val health = archive.getInputStream(archive.getEntry("product-health-ledger.json"))
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                assertTrue(health.contains("\"exportAttempts\""))
            }
        } finally {
            zip.delete()
            incidentStore.clear()
        }
    }

    @Test
    fun writeBundleExcludesHostileIncidentContentFromEveryEntry() {
        val context = RuntimeEnvironment.getApplication().applicationContext as Context
        val incidentStore = ExportIncidentStore.forContext(context)
        incidentStore.clear()
        val secret = "SECRET_JANE_PROJECT_TRANSCRIPT_93817"
        incidentStore.save(
            ExportIncidentBundle(
                id = "hostile-incident",
                appVersion = "v3.74.125",
                deviceModel = "Test device",
                androidSdk = 36,
                projectId = "private-project-id-93817",
                projectName = secret,
                failedPhase = "encoder",
                errorClass = "ExportException",
                errorMessage = "$secret failed at C:\\Users\\Jane\\private-video.mp4",
                encoderPath = "hardware: test.encoder",
                codecLabel = "H.264",
                resolutionLabel = "1080p",
                frameRate = 30,
                exportAudioOnly = false,
                hdrRequested = false,
                streamCopyAttempted = false,
                timelineDurationMs = 60_000,
                elapsedMs = 5_000,
                progressSamples = listOf(0.25f, 0.5f),
                mediaWarningCount = 2,
                mediaBlockingCount = 1,
                mediaHealthSummary = "$secret content://media/video/42 /storage/private.mov",
                timestampEpochMs = 1_718_200_000_000,
            )
        )

        val engine = DiagnosticExportEngine(
            context = context,
            crashRecordStore = CrashRecordStore(context),
            memoryTrimBreadcrumbStore = MemoryTrimBreadcrumbStore.forContextFilesDir(context.filesDir),
            processExitRecorder = ProcessExitRecorder(context),
            settingsResetReportStore = SettingsResetReportStore(context),
            exportIncidentStore = incidentStore,
            productHealthLedger = ProductHealthLedger(context),
        )
        val target = temp.newFile("privacy-diag.zip")

        try {
            engine.writeBundle(target, modelRegistry = emptyList(), now = 1_718_200_000_000)

            ZipFile(target).use { zip ->
                val entries = zip.entries().toList().filterNot { it.isDirectory }
                assertTrue(entries.any { it.name == ExportIncidentStore.BUNDLE_ENTRY })
                for (entry in entries) {
                    val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                    assertFalse("Secret leaked through ${entry.name}", text.contains(secret))
                    assertFalse("Project ID leaked through ${entry.name}", text.contains("private-project-id-93817"))
                    assertFalse("Path leaked through ${entry.name}", text.contains("private-video.mp4"))
                    assertFalse("URI leaked through ${entry.name}", text.contains("content://media/video/42"))
                }

                val incidentJson = zip.getInputStream(zip.getEntry(ExportIncidentStore.BUNDLE_ENTRY))
                    .bufferedReader(Charsets.UTF_8)
                    .use { it.readText() }
                assertTrue(incidentJson.contains("\"projectPseudonym\": \"project-1\""))
                assertTrue(incidentJson.contains("\"mediaWarningCount\": 2"))
                assertTrue(incidentJson.contains("\"mediaBlockingCount\": 1"))
                assertFalse(incidentJson.contains("\"errorMessage\""))
                assertFalse(incidentJson.contains("\"mediaHealthSummary\""))
            }
        } finally {
            incidentStore.clear()
        }
    }

    @Test
    fun aHeapDumpGoesInOnlyWhenTurnedOn() {
        val context = RuntimeEnvironment.getApplication().applicationContext as Context
        val recorder = ProcessExitRecorder(context)
        val dump = File(context.filesDir, "profiling/heap dump 1.hprof").apply {
            parentFile?.mkdirs()
            writeBytes(ByteArray(64 * 1024) { (it % 251).toByte() })
        }
        recorder.recordHeapDump(HeapDumpResult(ProcessExitRecorder.TRIGGER_TYPE_ANOMALY, 0, null, dump.path), nowEpochMs = 1_000L)
        val engine = DiagnosticExportEngine(
            context = context,
            crashRecordStore = CrashRecordStore(context),
            memoryTrimBreadcrumbStore = MemoryTrimBreadcrumbStore.forContextFilesDir(context.filesDir),
            processExitRecorder = recorder,
            settingsResetReportStore = SettingsResetReportStore(context),
            exportIncidentStore = ExportIncidentStore.forContext(context),
            productHealthLedger = ProductHealthLedger(context),
        )
        val withoutDump = temp.newFile("without-dump.zip")
        val withDump = temp.newFile("with-dump.zip")

        engine.writeBundle(withoutDump, modelRegistry = emptyList(), now = 1_718_200_000_000)
        engine.writeBundle(withDump, modelRegistry = emptyList(), now = 1_718_200_000_000, includeHeapDump = true)

        ZipFile(withoutDump).use { zip ->
            assertFalse(zip.entries().toList().any { it.name.startsWith("memory-dump/") })
            val manifest = zip.getInputStream(zip.getEntry("manifest.txt")).bufferedReader().use { it.readText() }
            assertFalse(manifest.contains("memory-dump/"))
            // Its name and size are still listed, without where it sits on the phone.
            val exits = zip.getInputStream(zip.getEntry(ProcessExitRecorder.BUNDLE_ENTRY)).bufferedReader().use { it.readText() }
            assertTrue(exits.contains("heap dump 1.hprof"))
            assertFalse(exits.contains("profiling"))
        }
        ZipFile(withDump).use { zip ->
            val entry = zip.getEntry("memory-dump/heap_dump_1.hprof")
            assertTrue("The dump entry is missing", entry != null)
            val bytes = zip.getInputStream(entry).use { it.readBytes() }
            assertTrue(bytes.contentEquals(dump.readBytes()))
            val manifest = zip.getInputStream(zip.getEntry("manifest.txt")).bufferedReader().use { it.readText() }
            assertTrue(manifest.contains("memory-dump/heap_dump_1.hprof\t65536 bytes"))
        }
    }
}
