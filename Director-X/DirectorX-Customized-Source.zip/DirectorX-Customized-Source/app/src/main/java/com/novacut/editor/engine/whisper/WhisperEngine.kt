package com.novacut.editor.engine.whisper

import android.content.Context
import android.media.MediaCodec
import com.novacut.editor.engine.AppLog
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import com.novacut.editor.engine.AudioDecodeBudget
import com.novacut.editor.engine.CodecInstanceBudget
import com.novacut.editor.engine.ModelDownloadManager
import com.novacut.editor.engine.OnnxSessionFactory
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.LongBuffer
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs
import kotlin.math.roundToInt
import com.novacut.editor.engine.redacted

data class WhisperSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

enum class WhisperModelState {
    NOT_DOWNLOADED, DOWNLOADING, READY, ERROR
}

@Singleton
class WhisperEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val modelDownloadManager: ModelDownloadManager
) {
    private val modelDir = File(context.filesDir, "whisper")
    private val encoderFile = File(modelDir, "encoder_model.onnx")
    private val decoderFile = File(modelDir, "decoder_model.onnx")
    private val vocabFile = File(modelDir, "vocab.json")

    private val _modelState = MutableStateFlow(
        if (hasMinimumModelFiles())
            WhisperModelState.READY else WhisperModelState.NOT_DOWNLOADED
    )
    val modelState: StateFlow<WhisperModelState> = _modelState.asStateFlow()

    private val _downloadProgress = MutableStateFlow(0f)
    val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

    @Volatile private var vocab: Map<Int, String>? = null
    @Volatile private var ortEnv: OrtEnvironment? = null

    companion object {
        private const val MODEL_REVISION = "2575352d61be1bf7225cf8f8b268a4678025fc58"
        private const val BASE_URL =
            "https://huggingface.co/onnx-community/whisper-tiny.en/resolve/$MODEL_REVISION"
        private const val ONNX_BASE_URL = "$BASE_URL/onnx"
        private const val ENCODER_URL = "$ONNX_BASE_URL/encoder_model.onnx"
        private const val DECODER_URL = "$ONNX_BASE_URL/decoder_model.onnx"
        private const val VOCAB_URL = "$BASE_URL/vocab.json"
        private const val ENCODER_SHA256 =
            "8c361b9430a5ef6619ee64b7fe06c725df19f36d508cc8b847064b34a888a3fe"
        private const val DECODER_SHA256 =
            "14f1d425a4821feeba77cf93eeeaf812ca816f2e3fec382b4f0fa93d29de710e"
        private const val VOCAB_SHA256 =
            "f6bd25a65e4e63ca31360e9fb11c7e4f9a391a78385d640acd814092dd6eee4f"
        private const val MIN_ENCODER_BYTES = 5L * 1024L * 1024L
        private const val MIN_DECODER_BYTES = 5L * 1024L * 1024L
        private const val MIN_VOCAB_BYTES = 4L * 1024L

        private const val MAX_DECODE_TOKENS = 224
        private const val ENCODER_HIDDEN = 384 // whisper-tiny hidden size
        private const val ENCODER_SEQ = 1500   // encoder output sequence length

        private const val ENCODER_ESTIMATED_BYTES = 32_904_992L
        private const val DECODER_ESTIMATED_BYTES = 118_395_947L
        private const val VOCAB_ESTIMATED_BYTES = 999_186L
        private const val TOTAL_ESTIMATED_BYTES =
            ENCODER_ESTIMATED_BYTES + DECODER_ESTIMATED_BYTES + VOCAB_ESTIMATED_BYTES

        fun estimateModelSizeMB(): Int = 146
    }

    private fun hasMinimumModelFiles(): Boolean {
        return encoderFile.exists() && encoderFile.length() >= MIN_ENCODER_BYTES &&
            decoderFile.exists() && decoderFile.length() >= MIN_DECODER_BYTES &&
            vocabFile.exists() && vocabFile.length() >= MIN_VOCAB_BYTES
    }

    private fun hasVerifiedModelFiles(): Boolean {
        return ModelDownloadManager.verifyChecksumOrDelete(
            file = encoderFile,
            minimumBytes = MIN_ENCODER_BYTES,
            expectedSha256 = ENCODER_SHA256,
        ) &&
            ModelDownloadManager.verifyChecksumOrDelete(
                file = decoderFile,
                minimumBytes = MIN_DECODER_BYTES,
                expectedSha256 = DECODER_SHA256,
            ) &&
            ModelDownloadManager.verifyChecksumOrDelete(
                file = vocabFile,
                minimumBytes = MIN_VOCAB_BYTES,
                expectedSha256 = VOCAB_SHA256,
            )
    }

    fun refreshModelState(): WhisperModelState {
        val state = when {
            !hasMinimumModelFiles() -> WhisperModelState.NOT_DOWNLOADED
            hasVerifiedModelFiles() -> WhisperModelState.READY
            else -> WhisperModelState.ERROR
        }
        _modelState.value = state
        return state
    }

    fun isReady(): Boolean = _modelState.value == WhisperModelState.READY && hasMinimumModelFiles()

    /**
     * Download Whisper tiny.en ONNX model files from HuggingFace.
     */
    suspend fun downloadModel(
        wifiOnly: Boolean = false,
        onProgress: (Float) -> Unit = {}
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            _modelState.value = WhisperModelState.DOWNLOADING
            _downloadProgress.value = 0f
            modelDir.mkdirs()

            val files = listOf(
                ModelDownloadManager.ModelFile(
                    url = ENCODER_URL,
                    targetFile = encoderFile,
                    minimumBytes = MIN_ENCODER_BYTES,
                    estimatedBytes = ENCODER_ESTIMATED_BYTES,
                    maxBytes = ENCODER_ESTIMATED_BYTES,
                    displayName = "Whisper encoder",
                    sha256 = ENCODER_SHA256,
                    checksumRequired = true
                ),
                ModelDownloadManager.ModelFile(
                    url = DECODER_URL,
                    targetFile = decoderFile,
                    minimumBytes = MIN_DECODER_BYTES,
                    estimatedBytes = DECODER_ESTIMATED_BYTES,
                    maxBytes = DECODER_ESTIMATED_BYTES,
                    displayName = "Whisper decoder",
                    sha256 = DECODER_SHA256,
                    checksumRequired = true
                ),
                ModelDownloadManager.ModelFile(
                    url = VOCAB_URL,
                    targetFile = vocabFile,
                    minimumBytes = MIN_VOCAB_BYTES,
                    estimatedBytes = VOCAB_ESTIMATED_BYTES,
                    maxBytes = VOCAB_ESTIMATED_BYTES,
                    displayName = "Whisper vocabulary",
                    sha256 = VOCAB_SHA256,
                    checksumRequired = true
                )
            )

            modelDownloadManager.downloadFiles(
                files = files,
                totalEstimateBytes = TOTAL_ESTIMATED_BYTES,
                connectTimeoutMs = 30_000,
                readTimeoutMs = 60_000,
                wifiOnly = wifiOnly
            ) { progress ->
                _downloadProgress.value = progress.coerceIn(0f, 0.99f)
                onProgress(_downloadProgress.value)
            }

            _downloadProgress.value = 1f
            onProgress(1f)
            if (hasVerifiedModelFiles()) {
                _modelState.value = WhisperModelState.READY
                true
            } else {
                _modelState.value = WhisperModelState.ERROR
                false
            }
        } catch (e: ModelDownloadManager.MeteredNetworkException) {
            _modelState.value = if (hasVerifiedModelFiles()) {
                WhisperModelState.READY
            } else {
                WhisperModelState.NOT_DOWNLOADED
            }
            _downloadProgress.value = 0f
            throw e
        } catch (e: CancellationException) {
            // User cancel is not a model failure — the generic catch below would
            // otherwise swallow it and surface a bogus ERROR state. Restore a
            // consistent state and propagate.
            _modelState.value = if (hasVerifiedModelFiles()) {
                WhisperModelState.READY
            } else {
                WhisperModelState.NOT_DOWNLOADED
            }
            _downloadProgress.value = 0f
            throw e
        } catch (e: Exception) {
            AppLog.w("WhisperEngine", "Model download failed", e)
            _modelState.value = if (hasVerifiedModelFiles()) {
                WhisperModelState.READY
            } else {
                WhisperModelState.ERROR
            }
            _downloadProgress.value = 0f
            false
        }
    }

    /**
     * Transcribe audio from a video/audio URI.
     * Returns timed segments with transcribed text.
     */
    suspend fun transcribe(
        uri: Uri,
        onProgress: (Float) -> Unit = {}
    ): List<WhisperSegment> = withContext(Dispatchers.IO) {
        if (!isReady()) return@withContext emptyList()
        if (!hasVerifiedModelFiles()) {
            _modelState.value = WhisperModelState.ERROR
            return@withContext emptyList()
        }

        onProgress(0.05f)

        // Step 1: Decode audio to PCM
        val (pcm, sampleRate) = decodeAudioToPcm(uri) ?: return@withContext emptyList()
        onProgress(0.15f)

        // Step 2: Resample to 16kHz if needed
        val audio16k = if (sampleRate != WhisperMel.SAMPLE_RATE) {
            resample(pcm, sampleRate, WhisperMel.SAMPLE_RATE)
        } else pcm
        onProgress(0.20f)

        // Step 3: Process in 30-second chunks
        val chunkSamples = WhisperMel.N_SAMPLES
        val numChunks = ((audio16k.size + chunkSamples - 1) / chunkSamples).coerceAtLeast(1)
        val allSegments = mutableListOf<WhisperSegment>()

        // Load vocab if not loaded
        if (vocab == null) loadVocab()
        val v = vocab ?: return@withContext emptyList()

        // Create ONNX sessions
        val env = ortEnv ?: OrtEnvironment.getEnvironment().also { ortEnv = it }
        var encoderHandle: OnnxSessionFactory.SessionHandle? = null
        var decoderHandle: OnnxSessionFactory.SessionHandle? = null

        try {
            try {
                encoderHandle = OnnxSessionFactory.createSession(env, encoderFile.absolutePath)
                decoderHandle = OnnxSessionFactory.createSession(env, decoderFile.absolutePath)
            } catch (e: Exception) {
                AppLog.e("WhisperEngine", "Failed to create ONNX sessions (model may be corrupt)", e)
                return@withContext emptyList()
            }
            val encoderSession = requireNotNull(encoderHandle).session
            val decoderSession = requireNotNull(decoderHandle).session

            for (chunk in 0 until numChunks) {
                // Long inputs mean many 30s chunks — honor cancellation per chunk.
                ensureActive()
                val chunkStart = chunk * chunkSamples
                val chunkAudio = FloatArray(chunkSamples)
                val copyLen = minOf(chunkSamples, audio16k.size - chunkStart)
                if (copyLen > 0) System.arraycopy(audio16k, chunkStart, chunkAudio, 0, copyLen)

                val chunkOffsetMs = (chunkStart.toLong() * 1000L) / WhisperMel.SAMPLE_RATE
                val chunkDurationMs = (copyLen.coerceAtLeast(0).toLong() * 1000L) / WhisperMel.SAMPLE_RATE

                // Whisper answers silence with "you" or "Thank you." while its no-speech
                // check lets the guess through, so audio too quiet to hold speech is skipped.
                if (WhisperDecoding.isTooQuietForSpeech(chunkAudio, copyLen)) {
                    onProgress(0.20f + 0.3f * (chunk + 1f) / numChunks)
                    continue
                }

                // Compute mel spectrogram
                val mel = WhisperMel.compute(chunkAudio)
                onProgress(0.20f + 0.3f * (chunk + 0.3f) / numChunks)

                // Run encoder
                val encoderOutput = runEncoder(env, encoderSession, mel)
                    ?: continue
                onProgress(0.20f + 0.3f * (chunk + 0.6f) / numChunks)

                // Run decoder (greedy with timestamps). Always close encoderOutput, even on exception.
                try {
                    val segments = runDecoder(env, decoderSession, encoderOutput, v, chunkOffsetMs, chunkDurationMs)
                    allSegments.addAll(segments)
                } finally {
                    try { encoderOutput.close() } catch (e: Exception) { AppLog.w("WhisperEngine", "encoderOutput close failed", e) }
                }
                onProgress(0.20f + 0.3f * (chunk + 1f) / numChunks)
            }
        } finally {
            try {
                encoderHandle?.close()
            } finally {
                decoderHandle?.close()
            }
        }

        onProgress(1f)

        // Merge adjacent segments with same text or very close timing
        mergeSegments(allSegments)
    }

    private fun runEncoder(
        env: OrtEnvironment,
        session: OrtSession,
        mel: FloatArray
    ): OnnxTensor? {
        val inputShape = longArrayOf(1, WhisperMel.N_MELS.toLong(), WhisperMel.N_FRAMES.toLong())
        val inputBuffer = FloatBuffer.wrap(mel)
        val inputTensor = OnnxTensor.createTensor(env, inputBuffer, inputShape)

        var results: OrtSession.Result? = null
        return try {
            results = session.run(mapOf("input_features" to inputTensor))
            val output = results.firstOrNull()?.value as? OnnxTensor ?: return null
            // Clone the tensor data before closing results so caller owns a fresh OnnxTensor.
            val data = output.floatBuffer
            val cloned = FloatArray(data.remaining())
            data.get(cloned)
            val shape = output.info.shape
            OnnxTensor.createTensor(env, FloatBuffer.wrap(cloned), shape)
        } catch (e: Exception) {
            AppLog.w("WhisperEngine", "Encoder run failed", e)
            null
        } finally {
            try { results?.close() } catch (e: Exception) { AppLog.w("WhisperEngine", "results close failed", e) }
            try { inputTensor.close() } catch (e: Exception) { AppLog.w("WhisperEngine", "inputTensor close failed", e) }
        }
    }

    // Suspend so each greedy step can honor cancellation (mirrors decodeAudioToPcm:
    // no CoroutineScope receiver here, so use currentCoroutineContext()).
    private suspend fun runDecoder(
        env: OrtEnvironment,
        session: OrtSession,
        encoderOutput: OnnxTensor,
        vocab: Map<Int, String>,
        chunkOffsetMs: Long,
        chunkDurationMs: Long,
    ): List<WhisperSegment> {
        // An English-only model takes no language or task token: the prompt is
        // <|startoftranscript|> alone.
        val tokens = mutableListOf(WhisperDecoding.SOT.toLong())
        val generated = mutableListOf<Int>()
        val decode = WhisperDecoding.ChunkDecode()

        for (step in 0 until MAX_DECODE_TOKENS) {
            currentCoroutineContext().ensureActive()
            val inputIds = LongBuffer.wrap(tokens.toLongArray())
            val inputShape = longArrayOf(1, tokens.size.toLong())
            var idTensor: OnnxTensor? = OnnxTensor.createTensor(env, inputIds, inputShape)
            var results: OrtSession.Result? = null

            val nextToken: Int
            try {
                results = session.run(mapOf(
                    "input_ids" to idTensor,
                    "encoder_hidden_states" to encoderOutput
                ))

                val logits = results.firstOrNull()?.value as? OnnxTensor
                if (logits == null) break

                // Validate shape before indexing — a malformed model output
                // with fewer than 3 dims (rank < 3) would throw
                // IndexOutOfBoundsException reading shape[2], leaking every
                // tensor accumulated in this decode loop and aborting
                // transcription silently. Bail cleanly instead.
                val shape = logits.info.shape
                if (shape.size < 3) {
                    com.novacut.editor.engine.AppLog.e("WhisperEngine", "Decoder logits have unexpected rank ${shape.size}; aborting")
                    break
                }
                val logitsData = logits.floatBuffer
                val vocabSize = shape[2].toInt()
                val seqLen = shape[1].toInt()
                if (vocabSize <= 0 || seqLen <= 0) {
                    com.novacut.editor.engine.AppLog.e("WhisperEngine", "Decoder logits have non-positive dims: shape=${shape.toList()}")
                    break
                }

                // Logits for the last token position
                val lastOffset = (seqLen - 1) * vocabSize
                val scores = FloatArray(vocabSize) { logitsData.get(lastOffset + it) }
                nextToken = decode.next(scores, generated)
            } catch (e: Exception) {
                AppLog.w("WhisperEngine", "Decoder step $step failed; keeping the text decoded so far", e)
                break
            } finally {
                results?.close()
                idTensor?.close()
                idTensor = null
            }

            if (nextToken == WhisperDecoding.EOT) break
            tokens.add(nextToken.toLong())
            generated.add(nextToken)
        }

        if (decode.isSilence(generated.size)) return emptyList()
        return WhisperDecoding.segments(generated, chunkOffsetMs, chunkDurationMs) { decodeTokens(it, vocab) }
    }

    private fun decodeTokens(tokenIds: List<Int>, vocab: Map<Int, String>): String {
        val sb = StringBuilder()
        for (id in tokenIds) {
            val text = vocab[id] ?: continue
            // Whisper GPT-2 vocab uses Unicode byte encoding (e.g. "Ġ" = space prefix)
            sb.append(text)
        }
        return Gpt2ByteDecoder.decode(sb.toString())
    }

    private fun loadVocab() {
        if (!vocabFile.exists()) return
        try {
            val json = JSONObject(vocabFile.readText(Charsets.UTF_8))
            val map = mutableMapOf<Int, String>()
            json.keys().forEach { key ->
                val tokenId = json.getInt(key)
                map[tokenId] = key
            }
            vocab = map
        } catch (e: Exception) {
            AppLog.w("WhisperEngine", "Failed to load vocab from $vocabFile", e)
        }
    }

    /**
     * Decode audio from URI to mono float32 PCM.
     * Returns (samples, sampleRate) or null on failure.
     */
    private suspend fun decodeAudioToPcm(uri: Uri): Pair<FloatArray, Int>? {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)

            var audioIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val tf = extractor.getTrackFormat(i)
                if (tf.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    audioIndex = i
                    format = tf
                    break
                }
            }
            if (audioIndex < 0 || format == null) return null

            extractor.selectTrack(audioIndex)
            val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            if (sampleRate <= 0 || channels <= 0) return null
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null

            val decoderLease = CodecInstanceBudget.acquireDecoder(mime)
            val decoder = decoderLease.resource
            val chunks = mutableListOf<FloatArray>()
            var totalSamples = 0

            try {
                decoder.configure(format, null, null, 0)
                decoder.start()
                val bufferInfo = MediaCodec.BufferInfo()
                var eos = false

                while (!eos) {
                    currentCoroutineContext().ensureActive()
                    val inIdx = decoder.dequeueInputBuffer(10000)
                    if (inIdx >= 0) {
                        val buf = decoder.getInputBuffer(inIdx) ?: continue
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            eos = true
                        } else {
                            decoder.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                    var outIdx = decoder.dequeueOutputBuffer(bufferInfo, 10000)
                    while (outIdx >= 0) {
                        val outBuf = decoder.getOutputBuffer(outIdx)
                        if (outBuf != null && bufferInfo.size > 1) {
                            val buf = outBuf.duplicate()
                            val start = bufferInfo.offset.coerceIn(0, buf.capacity())
                            val rawEnd = (bufferInfo.offset + bufferInfo.size).coerceIn(start, buf.capacity())
                            val end = rawEnd - ((rawEnd - start) % 2)
                            buf.position(start)
                            buf.limit(end)
                            val shortBuf = buf.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val samples = ShortArray(shortBuf.remaining())
                            shortBuf.get(samples)
                            // Mix to mono
                            val mono = FloatArray(samples.size / channels)
                            for (i in mono.indices) {
                                var sum = 0f
                                for (ch in 0 until channels) {
                                    val idx = i * channels + ch
                                    if (idx < samples.size) sum += samples[idx].toFloat()
                                }
                                mono[i] = sum / channels / 32768f
                            }
                            if (AudioDecodeBudget.exceedsBudget(totalSamples, mono.size)) {
                                AppLog.w("WhisperEngine", "Decoded PCM exceeds the in-memory budget; stopping decode")
                                decoder.releaseOutputBuffer(outIdx, false)
                                eos = true
                                break
                            }
                            chunks.add(mono)
                            totalSamples += mono.size
                        }
                        decoder.releaseOutputBuffer(outIdx, false)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            eos = true; break
                        }
                        outIdx = decoder.dequeueOutputBuffer(bufferInfo, 0)
                    }
                }
            } finally {
                decoderLease.close()
            }

            if (totalSamples == 0) return null

            val allSamples = FloatArray(totalSamples)
            var offset = 0
            for (chunk in chunks) {
                System.arraycopy(chunk, 0, allSamples, offset, chunk.size)
                offset += chunk.size
            }
            return allSamples to sampleRate
        } catch (e: Exception) {
            AppLog.w("WhisperEngine", "PCM decode failed for ${uri.redacted()}", e)
            return null
        } finally {
            extractor.release()
        }
    }

    /**
     * Linear interpolation resampling.
     */
    private fun resample(input: FloatArray, srcRate: Int, dstRate: Int): FloatArray {
        if (srcRate == dstRate) return input
        // A malformed container can report a 0/negative sample rate; without this guard
        // ratio becomes Infinity → outLen overflows → OOM/crash. Skip resampling instead.
        if (srcRate <= 0 || dstRate <= 0) return input
        val ratio = dstRate.toDouble() / srcRate.toDouble()
        val outLen = (input.size * ratio).roundToInt()
        val output = FloatArray(outLen)
        for (i in 0 until outLen) {
            val srcPos = i / ratio
            val srcIdx = srcPos.toInt()
            val frac = (srcPos - srcIdx).toFloat()
            val s0 = input.getOrElse(srcIdx) { 0f }
            val s1 = input.getOrElse(srcIdx + 1) { s0 }
            output[i] = s0 + frac * (s1 - s0)
        }
        return output
    }

    /**
     * Merge segments: combine adjacent segments, remove duplicates.
     */
    private fun mergeSegments(segments: List<WhisperSegment>): List<WhisperSegment> {
        if (segments.size < 2) return segments
        val merged = mutableListOf(segments[0])
        for (i in 1 until segments.size) {
            val prev = merged.last()
            val curr = segments[i]
            // Merge if gap < 200ms and same/similar text continuation
            if (curr.startMs - prev.endMs < 200 && curr.text == prev.text) {
                merged[merged.lastIndex] = prev.copy(endMs = curr.endMs)
            } else {
                merged.add(curr)
            }
        }
        return merged
    }

    fun deleteModel() {
        modelDir.deleteRecursively()
        vocab = null
        _modelState.value = WhisperModelState.NOT_DOWNLOADED
        _downloadProgress.value = 0f
    }

    fun getModelSizeMB(): Long {
        return getModelSizeBytes().div(1024 * 1024)
    }

    fun getModelSizeBytes(): Long {
        return if (modelDir.exists()) {
            modelDir.listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
        } else 0L
    }
}

/**
 * Reverse of GPT-2's `bytes_to_unicode`: maps the vocab's Unicode chars back to
 * raw bytes, then decodes the byte stream as UTF-8 (with replacement).
 *
 * `bytes_to_unicode` keeps the printable ranges 0x21–0x7E, 0xA1–0xAC and
 * 0xAE–0xFF as themselves and remaps the remaining 68 bytes (0x00–0x20,
 * 0x7F–0xA0, 0xAD) to U+0100+n in order of appearance — so "Ġ" (U+0120) is byte
 * 0x20 (space) and "Ċ" (U+010A) is 0x0A. The previous char-by-char arithmetic
 * assumed code−0x100 for the whole U+0100..U+0200 range (wrong for
 * U+0121–U+0143, which are bytes 0x7F–0xA0 and 0xAD) and appended the mapped
 * bytes as chars instead of UTF-8-decoding them, corrupting curly quotes and
 * every non-ASCII transcription. Pure object so the contract is JVM-testable.
 */
internal object Gpt2ByteDecoder {
    private val charToByte: Map<Char, Byte> = buildMap {
        val selfMapped = (0x21..0x7E) + (0xA1..0xAC) + (0xAE..0xFF)
        for (b in selfMapped) put(b.toChar(), b.toByte())
        var n = 0
        for (b in 0..0xFF) {
            if (b !in selfMapped) {
                put((0x100 + n).toChar(), b.toByte())
                n++
            }
        }
    }

    fun decode(text: String): String {
        val bytes = java.io.ByteArrayOutputStream(text.length)
        for (ch in text) {
            val mapped = charToByte[ch]
            if (mapped != null) {
                bytes.write(mapped.toInt())
            } else {
                // Not a byte-encoder char (should not occur in a valid GPT-2 vocab):
                // pass it through as its own UTF-8 bytes rather than dropping it.
                bytes.write(ch.toString().toByteArray(Charsets.UTF_8))
            }
        }
        // String(bytes, UTF_8) substitutes U+FFFD for malformed sequences.
        return String(bytes.toByteArray(), Charsets.UTF_8)
    }
}
